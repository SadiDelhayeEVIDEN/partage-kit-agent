/*
 * Constantes métier (version "nouvelle", 2022).
 */
SL.shared.constants = {
  TVA: {
    default: 0.2,
    books: 0.055,
    food: 0.055,
    electronics: 0.2,
    clothing: 0.2,
    home: 0.2
  },
  ORDER_STATUS: {
    PENDING: 'PENDING',
    PAID: 'PAID',
    SHIPPED: 'SHIPPED',
    CANCELLED: 'CANCELLED',
    FAILED: 'FAILED'
  },
  CATEGORIES: ['electronics', 'books', 'clothing', 'food', 'home'],
  CATEGORY_LABELS: {
    electronics: 'High-tech',
    books: 'Livres',
    clothing: 'Vêtements',
    food: 'Épicerie',
    home: 'Maison'
  },
  LOW_STOCK_THRESHOLD: 3
};
