/*
 * old-helpers.js - fonctions de la v1.
 * Ce fichier n'est plus chargé par index.html depuis 2020... normalement.
 */
function calcPrice(p, qty, cat) {
  var tva = cat == 'book' ? 0.055 : 0.196; // TVA 2013
  return p * qty * (1 + tva);
}

function getUserFromCookie() {
  var m = document.cookie.match(/user=([^;]+)/);
  return m ? JSON.parse(decodeURIComponent(m[1])) : null;
}

function sendMailLegacy(to, subject) {
  var xhr = new XMLHttpRequest();
  xhr.open('POST', 'http://mail.shoplegacy.local/send', false);
  xhr.send(JSON.stringify({ to: to, subject: subject }));
}
