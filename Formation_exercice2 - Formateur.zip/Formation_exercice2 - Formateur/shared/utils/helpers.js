/*
 * helpers.js - "boîte à outils" historique.
 * Tout le monde y ajoute ses fonctions. Merci de ne rien casser.
 */
SL.helpers = {
  // ---------- Format ----------
  formatPrice: function (value) {
    return Number(value).toFixed(2).replace('.', ',') + ' ' + CURRENCY_SYMBOL;
  },

  formatDate: function (ts) {
    var d = new Date(ts);
    return d.toLocaleDateString('fr-FR') + ' ' + d.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
  },

  round2: function (n) {
    return Math.round(n * 100) / 100;
  },

  // ---------- Prix (copie de pricing, plus simple) ----------
  computeTotalTTC: function (priceHT, category) {
    var rate = SL.shared.constants.TVA[category] !== undefined ? SL.shared.constants.TVA[category] : SL.shared.constants.TVA.default;
    return Math.round(priceHT * (1 + rate) * 100) / 100;
  },

  // ---------- Validation (doublon de shared/validators) ----------
  validateEmail: function (email) {
    return String(email || '').indexOf('@') > 0;
  },

  // ---------- Erreurs ----------
  httpError: function (status, message) {
    var e = new Error(message);
    e.status = status;
    return e;
  },

  // ---------- Divers ----------
  uuid: function () {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
      var r = (Math.random() * 16) | 0;
      var v = c === 'x' ? r : (r & 0x3) | 0x8;
      return v.toString(16);
    });
  },

  deepClone: function (obj) {
    return JSON.parse(JSON.stringify(obj));
  },

  debounce: function (fn, wait) {
    var t;
    return function () {
      var args = arguments, ctx = this;
      clearTimeout(t);
      t = setTimeout(function () { fn.apply(ctx, args); }, wait);
    };
  },

  sleep: function (ms) {
    return new Promise(function (r) { setTimeout(r, ms); });
  },

  escapeHtml: function (str) {
    return String(str === undefined || str === null ? '' : str)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  },

  // ---------- Accès direct aux données (raccourci, pas le temps de passer par l'API) ----------
  getCurrentUser: function () {
    var token = SL.infra.storage.getValue('token');
    if (!token) return null;
    var session = SL.infra.storage.get('sessions').find(function (s) { return s.token === token; });
    if (!session) return null;
    return SL.infra.storage.get('users').find(function (u) { return u.id === session.userId; }) || null;
  },

  // ---------- DOM ----------
  qs: function (sel, root) {
    return (root || document).querySelector(sel);
  },

  qsa: function (sel, root) {
    return Array.prototype.slice.call((root || document).querySelectorAll(sel));
  }
};
