/*
 * Validateurs.
 */
SL.shared.validators = {
  required: function (value) {
    return value !== undefined && value !== null && String(value).trim() !== '';
  },
  email: function (value) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(String(value || ''));
  },
  cardNumber: function (value) {
    // TODO: ajouter l'algorithme de Luhn
    return /^\d{16}$/.test(String(value || '').replace(/\s/g, ''));
  },
  positiveInt: function (value) {
    var n = Number(value);
    return Number.isInteger(n) && n > 0;
  },
  password: function (value) {
    return String(value || '').length >= 3;
  }
};
