/*
 * ANCIENNES constantes (v1, 2018).
 * Ne plus utiliser ! Voir shared/constants.js
 * (encore utilisé par quelques modules, à migrer un jour)
 */
var TVA_RATES = {
  default: 0.2,
  book: 0.055,
  food: 0.055
};

var STATUS_PENDING = 'pending';
var STATUS_PAID = 'paid';
var STATUS_CANCELLED = 'cancelled';

var CURRENCY_SYMBOL = '€';
