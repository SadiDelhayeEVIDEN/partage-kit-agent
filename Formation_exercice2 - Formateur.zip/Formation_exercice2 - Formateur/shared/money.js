/*
 * Utilitaires monétaires (ajoutés en 2023, utilisés uniquement par shipping pour l'instant).
 */
SL.shared.money = {
  round: function (value) {
    return Math.round((Number(value) + Number.EPSILON) * 100) / 100;
  },
  add: function (a, b) {
    return SL.shared.money.round(a + b);
  },
  multiply: function (a, factor) {
    return SL.shared.money.round(a * factor);
  },
  format: function (value) {
    return SL.shared.money.round(value).toFixed(2).replace('.', ',') + ' €';
  }
};
