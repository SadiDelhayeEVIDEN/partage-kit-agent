SL.controllers.order = {
  checkout: function (req) {
    return SL.services.order.checkout(req.user.id, req.body).then(function (order) {
      return { status: 201, body: order };
    });
  },
  mine: function (req) {
    return { status: 200, body: SL.services.order.listByUser(req.user.id) };
  },
  all: function () {
    return { status: 200, body: SL.services.order.all() };
  },
  updateStatus: function (req) {
    return { status: 200, body: SL.services.order.updateStatus(req.params.id, (req.body || {}).status) };
  }
};
