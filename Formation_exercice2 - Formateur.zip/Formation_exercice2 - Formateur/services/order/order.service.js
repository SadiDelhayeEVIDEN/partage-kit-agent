/*
 * Service commandes : orchestre panier, livraison, stock, paiement, événements.
 */
SL.services.order = {
  checkout: function (userId, data) {
    data = data || {};
    var cart = SL.services.cart.summary(userId);
    if (!cart.items.length) throw SL.helpers.httpError(400, 'Panier vide');
    if (!SL.shared.validators.required(data.address)) throw SL.helpers.httpError(400, 'Adresse requise');

    var total = SL.services.promo.applyPromo(cart.totalTTC, cart.promoCode);

    // appel au service de livraison via la gateway
    var url = '/api/shipping/quote?subtotal=' + total + '&weight=' + cart.weight;
    return SL.infra.http.request('GET', url, null, { 'x-caller': 'order' }).then(function (res) {
      var shipping = res.body.shipping;

      var order = SL.models.Order({
        id: SL.infra.storage.nextId('orders'),
        userId: userId,
        items: cart.items,
        subtotalHT: cart.subtotalHT,
        tva: cart.tva,
        discount: cart.totalBeforePromo - total,
        shipping: shipping,
        total: total + shipping,
        promoCode: cart.promoCode,
        address: data.address
      });
      SL.repositories.order.save(order);

      SL.services.inventory.reserveForOrder(order);
      SL.infra.bus.emit('order.created', order, 'order');

      var result = SL.services.payment.pay(order.id, data.card);
      SL.services.cart.clear(userId);

      if (!result.ok) {
        throw SL.helpers.httpError(402, 'Paiement refusé : ' + result.reason);
      }
      return SL.repositories.order.findById(order.id);
    });
  },

  get: function (id) {
    var o = SL.repositories.order.findById(id);
    if (!o) throw SL.helpers.httpError(404, 'Commande introuvable');
    return o;
  },

  listByUser: function (userId) {
    return SL.repositories.order.byUser(userId).sort(function (a, b) { return b.createdAt - a.createdAt; });
  },

  all: function () {
    return SL.repositories.order.all().sort(function (a, b) { return b.createdAt - a.createdAt; });
  },

  markPaid: function (id, transactionId) {
    var o = this.get(id);
    o.status = SL.shared.constants.ORDER_STATUS.PAID;
    o.transactionId = transactionId;
    SL.repositories.order.save(o);
    SL.infra.bus.emit('order.paid', o, 'order');
  },

  markFailed: function (id, reason) {
    var o = this.get(id);
    o.status = SL.shared.constants.ORDER_STATUS.FAILED;
    o.failureReason = reason;
    SL.repositories.order.save(o);
    SL.infra.bus.emit('order.failed', o, 'order');
  },

  updateStatus: function (id, status) {
    if (!SL.shared.constants.ORDER_STATUS[status]) throw SL.helpers.httpError(400, 'Statut inconnu');
    var o = this.get(id);
    o.status = status;
    SL.repositories.order.save(o);
    SL.infra.bus.emit('order.' + status.toLowerCase(), o, 'order');
    return o;
  }
};
