SL.repositories.order = {
  all: function () {
    return SL.infra.storage.get('orders');
  },
  findById: function (id) {
    return this.all().find(function (o) { return o.id == id; }) || null;
  },
  byUser: function (userId) {
    return this.all().filter(function (o) { return o.userId === userId; });
  },
  save: function (order) {
    var orders = this.all();
    var idx = orders.findIndex(function (o) { return o.id === order.id; });
    if (idx >= 0) orders[idx] = order;
    else orders.push(order);
    SL.infra.storage.save('orders', orders);
    return order;
  }
};
