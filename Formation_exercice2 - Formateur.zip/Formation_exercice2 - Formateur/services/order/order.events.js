/*
 * Liste des événements émis par le domaine "commande" (documentation).
 * Pas utilisé dans le code : les noms sont écrits en dur partout.
 */
SL.events = SL.events || {};
SL.events.order = {
  CREATED: 'order.created',
  PAID: 'order.paid',
  FAILED: 'order.failed',
  SHIPPED: 'order.shipped',
  CANCELED: 'order.canceled'
};
