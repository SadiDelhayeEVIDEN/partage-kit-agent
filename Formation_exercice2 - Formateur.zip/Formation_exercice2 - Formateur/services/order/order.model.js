SL.models.Order = function (data) {
  return {
    id: data.id,
    userId: data.userId,
    items: data.items || [],
    subtotalHT: data.subtotalHT,
    tva: data.tva,
    discount: data.discount || 0,
    shipping: data.shipping || 0,
    total: data.total,
    promoCode: data.promoCode || null,
    address: data.address || '',
    status: data.status || SL.shared.constants.ORDER_STATUS.PENDING,
    createdAt: data.createdAt || Date.now(),
    transactionId: data.transactionId || null,
    failureReason: data.failureReason || null
  };
};
