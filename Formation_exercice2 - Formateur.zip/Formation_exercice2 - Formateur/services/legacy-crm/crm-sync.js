/*
 * Synchronisation avec l'ancien CRM (décommissionné en 2021).
 * Fichier non chargé. Conservé "au cas où".
 */
SL.services.crm = {
  endpoint: 'http://crm.shoplegacy.local/api/v1',
  token: 'crm_8f7e6d5c4b3a',

  syncCustomer: function (user) {
    return fetch(this.endpoint + '/customers', {
      method: 'POST',
      headers: { Authorization: 'Bearer ' + this.token },
      body: JSON.stringify({ email: user.email, name: user.name, password: user.password })
    });
  },

  syncOrder: function (order) {
    var user = SL.repositories.user.findById(order.userId);
    this.syncCustomer(user);
    return fetch(this.endpoint + '/orders', { method: 'POST', body: JSON.stringify(order) });
  }
};
