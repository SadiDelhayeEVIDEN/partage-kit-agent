SL.repositories.catalog = {
  all: function () {
    return SL.infra.storage.get('products').map(SL.models.Product);
  },

  findById: function (id) {
    return this.all().find(function (p) { return p.id == id; }) || null;
  },

  paginate: function (items, page, size) {
    var start = (page - 1) * size;
    var end = start + size - 1;
    return items.slice(start, end);
  }
};
