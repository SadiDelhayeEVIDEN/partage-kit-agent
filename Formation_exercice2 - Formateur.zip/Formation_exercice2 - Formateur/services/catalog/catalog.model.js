SL.models.Product = function (raw) {
  return {
    id: Number(raw.id),
    name: raw.name,
    price: parseFloat(raw.price),
    category: raw.category,
    weight: raw.weight || 0.5,
    image: raw.image || '📦',
    description: raw.description || ''
  };
};
