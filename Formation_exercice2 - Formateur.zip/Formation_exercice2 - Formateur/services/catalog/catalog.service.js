SL.services.catalog = {
  list: function (opts) {
    opts = opts || {};
    var page = parseInt(opts.page, 10) || 1;
    var size = SL.config.pageSize;
    var items = SL.repositories.catalog.all();

    if (opts.category) {
      items = items.filter(function (p) { return p.category === opts.category; });
    }
    if (opts.search) {
      var s = opts.search.toLowerCase();
      items = items.filter(function (p) { return p.name.toLowerCase().indexOf(s) >= 0; });
    }

    var total = items.length;
    var pageItems = SL.repositories.catalog.paginate(items, page, size).map(function (p) {
      return Object.assign({}, p, {
        stock: SL.services.inventory.getStock(p.id),
        priceTTC: SL.helpers.computeTotalTTC(p.price, p.category)
      });
    });

    return {
      items: pageItems,
      page: page,
      pageSize: size,
      total: total,
      totalPages: Math.ceil(total / size)
    };
  },

  get: function (id) {
    var p = SL.repositories.catalog.findById(id);
    if (!p) throw SL.helpers.httpError(404, 'Produit introuvable');
    return Object.assign({}, p, {
      stock: SL.services.inventory.getStock(p.id),
      priceTTC: SL.helpers.computeTotalTTC(p.price, p.category)
    });
  },

  categories: function () {
    return SL.shared.constants.CATEGORIES.map(function (c) {
      return { id: c, label: SL.shared.constants.CATEGORY_LABELS[c] };
    });
  }
};
