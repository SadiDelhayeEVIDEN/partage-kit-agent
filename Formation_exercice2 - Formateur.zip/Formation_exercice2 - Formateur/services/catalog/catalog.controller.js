SL.controllers.catalog = {
  list: function (req) {
    return { status: 200, body: SL.services.catalog.list(req.query) };
  },
  get: function (req) {
    return { status: 200, body: SL.services.catalog.get(req.params.id) };
  },
  categories: function () {
    return { status: 200, body: SL.services.catalog.categories() };
  }
};
