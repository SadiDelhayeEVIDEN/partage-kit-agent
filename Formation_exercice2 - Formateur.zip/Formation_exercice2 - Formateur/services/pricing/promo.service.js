SL.services.promo = {
  codes: {
    BIENVENUE10: { type: 'percent', value: 10, label: '-10 % sur votre commande' },
    LEGACY5: { type: 'fixed', value: 5, label: '-5 € sur votre commande' },
    NOEL25: { type: 'percent', value: 25, label: '-25 % (Noël 2023)', expires: '2023-12-31' }
  },

  validate: function (code) {
    if (!SL.config.features.promo) return null;
    var c = this.codes[String(code || '').toUpperCase()];
    if (!c) return null;
    if (c.expires && new Date(c.expires) < new Date()) return null;
    return c;
  },

  applyPromo: function (total, code) {
    var c = this.validate(code);
    if (!c) return total;
    if (c.type === 'percent') return total - (total * c.value) / 100;
    return Math.max(0, total - c.value);
  }
};
