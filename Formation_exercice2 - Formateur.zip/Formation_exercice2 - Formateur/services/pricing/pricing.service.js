SL.services.pricing = {
  // items : [{ productId, price (HT), qty, category }]
  computeCart: function (items) {
    var subtotalHT = 0;
    var tva = 0;
    (items || []).forEach(function (i) {
      var ht = SL.pricingRules.lineHT(i.price, i.qty);
      subtotalHT += ht;
      tva += ht * SL.pricingRules.tvaFor(i.category);
    });
    return {
      subtotalHT: subtotalHT,
      tva: tva,
      totalTTC: subtotalHT + tva
    };
  }
};
