/*
 * Règles de prix (2018). Utilise encore TVA_RATES de constants-old.js.
 */
SL.pricingRules = {
  tvaFor: function (category) {
    return TVA_RATES[category] !== undefined ? TVA_RATES[category] : TVA_RATES['default'];
  },
  lineHT: function (price, qty) {
    return price * qty;
  }
};
