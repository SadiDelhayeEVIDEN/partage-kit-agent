SL.controllers.pricing = {
  checkPromo: function (req) {
    var promo = SL.services.promo.validate(req.params.code);
    if (!promo) return { status: 404, body: { error: 'Code promo invalide ou expiré' } };
    return { status: 200, body: promo };
  }
};
