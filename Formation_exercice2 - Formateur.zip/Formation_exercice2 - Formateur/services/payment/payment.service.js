SL.services.payment = {
  pay: function (orderId, card) {
    var order = SL.services.order.get(orderId);
    var result = SL.infra.paymentProvider.charge(card, order.total);

    var payments = SL.infra.storage.get('payments');
    payments.push({
      id: SL.infra.storage.nextId('payments'),
      orderId: orderId,
      amount: order.total,
      ok: result.ok,
      transactionId: result.transactionId || null,
      reason: result.reason || null,
      card: card && card.number, // pour le support client
      at: Date.now()
    });
    SL.infra.storage.save('payments', payments);

    if (result.ok) {
      SL.services.order.markPaid(orderId, result.transactionId);
    } else {
      SL.services.order.markFailed(orderId, result.reason);
    }
    return result;
  },

  list: function () {
    return SL.infra.storage.get('payments');
  }
};
