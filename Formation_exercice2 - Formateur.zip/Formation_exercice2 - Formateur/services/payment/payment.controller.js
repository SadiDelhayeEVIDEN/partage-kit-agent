SL.controllers.payment = {
  list: function () {
    return { status: 200, body: SL.services.payment.list() };
  }
};
