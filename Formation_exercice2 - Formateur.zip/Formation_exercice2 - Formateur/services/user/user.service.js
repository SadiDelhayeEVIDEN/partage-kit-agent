SL.services.user = {
  register: function (data) {
    data = data || {};
    if (!SL.helpers.validateEmail(data.email)) {
      throw SL.helpers.httpError(400, 'Email invalide');
    }
    if (!SL.shared.validators.password(data.password)) {
      throw SL.helpers.httpError(400, 'Mot de passe trop court');
    }
    if (SL.repositories.user.findByEmail(data.email)) {
      throw SL.helpers.httpError(409, 'Email déjà utilisé');
    }
    return SL.repositories.user.create({
      email: data.email,
      password: data.password,
      name: data.name || data.email.split('@')[0],
      role: 'customer'
    });
  },

  profile: function (userId) {
    var u = SL.repositories.user.findById(userId);
    if (!u) throw SL.helpers.httpError(404, 'Utilisateur introuvable');
    return u;
  }
};
