SL.controllers.user = {
  login: function (req) {
    var body = req.body || {};
    var result = SL.services.auth.login(body.email, body.password);
    return { status: 200, body: result };
  },

  register: function (req) {
    var user = SL.services.user.register(req.body);
    var result = SL.services.auth.login(user.email, user.password);
    return { status: 201, body: result };
  },

  logout: function (req) {
    SL.services.auth.logout(req.headers.authorization);
    return { status: 204, body: null };
  },

  me: function (req) {
    return { status: 200, body: SL.services.user.profile(req.user.id) };
  }
};
