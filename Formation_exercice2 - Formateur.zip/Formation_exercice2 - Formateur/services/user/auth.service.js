/*
 * Service d'authentification (sessions par token).
 */
SL.services.auth = {
  login: function (email, password) {
    var user = SL.repositories.user.findByEmail(email);
    if (!user || user.password != password) {
      throw SL.helpers.httpError(401, 'Identifiants invalides');
    }
    var token = btoa(user.email + ':' + Date.now() + ':' + Math.random());
    var sessions = SL.infra.storage.get('sessions');
    sessions.push({ token: token, userId: user.id, createdAt: Date.now() });
    SL.infra.storage.save('sessions', sessions);
    SL.services.analytics.track('auth.login', { userId: user.id });
    return { token: token, user: user };
  },

  logout: function (token) {
    var sessions = SL.infra.storage.get('sessions').filter(function (s) { return s.token !== token; });
    SL.infra.storage.save('sessions', sessions);
  },

  resolveToken: function (token) {
    var session = SL.infra.storage.get('sessions').find(function (s) { return s.token === token; });
    if (!session) return null;
    return SL.repositories.user.findById(session.userId);
  },

  isAdmin: function (user) {
    return !!(user && (user.role = 'admin'));
  }
};
