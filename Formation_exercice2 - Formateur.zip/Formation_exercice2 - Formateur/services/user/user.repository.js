SL.repositories.user = {
  all: function () {
    return SL.infra.storage.get('users');
  },
  findById: function (id) {
    return this.all().find(function (u) { return u.id === id; }) || null;
  },
  findByEmail: function (email) {
    var e = String(email || '').toLowerCase();
    return this.all().find(function (u) { return u.email.toLowerCase() === e; }) || null;
  },
  create: function (user) {
    var users = this.all();
    user.id = SL.infra.storage.nextId('users');
    users.push(user);
    SL.infra.storage.save('users', users);
    return user;
  }
};
