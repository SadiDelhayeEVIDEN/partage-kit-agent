SL.services.shipping = {
  // Livraison offerte à partir de SL.config.shipping.freeThreshold € d'achat
  compute: function (subtotal, weightKg) {
    var cfg = SL.config.shipping;
    if (subtotal > cfg.freeThreshold) return 0;
    return SL.shared.money.round(cfg.baseRate + cfg.perKg * (weightKg || 0));
  }
};
