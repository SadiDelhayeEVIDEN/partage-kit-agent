/*
 * Grille tarifaire transporteurs (non utilisée pour l'instant : tarif unique).
 */
SL.shippingRates = {
  carriers: [
    { id: 'colissimo', label: 'Colissimo', base: 4.9, perKg: 1.2, days: 3 },
    { id: 'chronopost', label: 'Chronopost', base: 9.9, perKg: 2.0, days: 1 },
    { id: 'relay', label: 'Point relais', base: 3.5, perKg: 0.8, days: 5 }
  ],
  defaultCarrier: 'colissimo'
};
