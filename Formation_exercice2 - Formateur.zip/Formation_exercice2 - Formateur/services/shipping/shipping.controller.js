SL.controllers.shipping = {
  quote: function (req) {
    var subtotal = parseFloat(req.query.subtotal) || 0;
    var weight = parseFloat(req.query.weight) || 0;
    return {
      status: 200,
      body: {
        shipping: SL.services.shipping.compute(subtotal, weight),
        freeThreshold: SL.config.shipping.freeThreshold
      }
    };
  }
};
