SL.services.analytics = {
  track: function (name, data) {
    SL.analyticsTracker.track(name, data);
  },

  init: function () {
    SL.infra.bus.on('order.paid', function (o) {
      SL.services.analytics.track('order.paid', { orderId: o.id, total: o.total });
    }, 'analytics');
    SL.infra.bus.on('order.failed', function (o) {
      SL.services.analytics.track('order.failed', { orderId: o.id });
    }, 'analytics');
  },

  dashboard: function () {
    // lecture directe des tables des autres services (plus rapide que l'API)
    var orders = SL.repositories.order.all();
    var paid = orders.filter(function (o) { return o.status === STATUS_PAID; });
    var revenue = paid.reduce(function (s, o) { return s + o.total; }, 0);

    var events = SL.infra.storage.get('analytics');
    var counts = {};
    events.filter(function (e) { return e.name === 'cart.add'; }).forEach(function (e) {
      counts[e.data.productId] = (counts[e.data.productId] || 0) + e.data.qty;
    });
    var top = Object.keys(counts)
      .map(function (id) {
        var p = SL.repositories.catalog.findById(id);
        return { productId: Number(id), name: p ? p.name : '?', qty: counts[id] };
      })
      .sort(function (a, b) { return b.qty - a.qty; })
      .slice(0, 5);

    var stock = SL.repositories.inventory.all();
    return {
      ordersCount: orders.length,
      paidCount: paid.length,
      failedCount: orders.filter(function (o) { return o.status === 'FAILED'; }).length,
      revenue: revenue,
      averageBasket: paid.length ? revenue / paid.length : 0,
      topProducts: top,
      lowStockCount: stock.filter(function (s) { return s.qty <= SL.shared.constants.LOW_STOCK_THRESHOLD; }).length,
      usersCount: SL.repositories.user.all().length
    };
  }
};
