/*
 * Tracker d'événements analytics (stockés dans la table "analytics").
 */
SL.analyticsTracker = {
  buffer: [],
  track: function (name, data) {
    if (!SL.config.features.analytics) return;
    var rows = SL.infra.storage.get('analytics');
    rows.push({ name: name, data: data || {}, at: Date.now() });
    if (rows.length > 1000) rows = rows.slice(-1000);
    SL.infra.storage.save('analytics', rows);
  }
};
