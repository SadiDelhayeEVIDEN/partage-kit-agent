SL.controllers.analytics = {
  dashboard: function () {
    return { status: 200, body: SL.services.analytics.dashboard() };
  }
};
