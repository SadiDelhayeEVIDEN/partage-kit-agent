/*
 * Le panier est lié à l'utilisateur connecté, sinon à "guest".
 */
SL.controllers.cart = {
  _userId: function (req) {
    return req.user ? req.user.id : 'guest';
  },
  get: function (req) {
    return { status: 200, body: SL.services.cart.summary(this._userId(req)) };
  },
  addItem: function (req) {
    var body = req.body || {};
    return { status: 200, body: SL.services.cart.addItem(this._userId(req), body.productId, body.qty) };
  },
  removeItem: function (req) {
    return { status: 200, body: SL.services.cart.removeItem(this._userId(req), req.params.productId) };
  },
  setPromo: function (req) {
    return { status: 200, body: SL.services.cart.setPromo(this._userId(req), (req.body || {}).code) };
  }
};
