SL.services.cart = {
  get: function (userId) {
    return SL.repositories.cart.get(userId);
  },

  addItem: function (userId, productId, qty) {
    qty = parseInt(qty, 10) || 1;
    var product = SL.services.catalog.get(productId);
    if (product.stock < qty) {
      throw SL.helpers.httpError(409, 'Stock insuffisant pour ' + product.name);
    }
    var cart = SL.repositories.cart.get(userId);
    var line = cart.items.find(function (i) { return i.productId == product.id; });
    if (line) {
      line.qty += qty;
    } else {
      cart.items.push({
        productId: product.id,
        name: product.name,
        image: product.image,
        price: product.price,
        category: product.category,
        weight: product.weight,
        qty: qty
      });
    }
    SL.repositories.cart.save(cart);
    SL.services.analytics.track('cart.add', { userId: userId, productId: product.id, qty: qty });
    return this.summary(userId);
  },

  removeItem: function (userId, productId) {
    var cart = SL.repositories.cart.get(userId);
    cart.items = cart.items.filter(function (i) { return i.productId !== productId; });
    SL.repositories.cart.save(cart);
    return this.summary(userId);
  },

  setPromo: function (userId, code) {
    if (!SL.services.promo.validate(code)) {
      throw SL.helpers.httpError(400, 'Code promo invalide');
    }
    var cart = SL.repositories.cart.get(userId);
    cart.promoCode = String(code).toUpperCase();
    SL.repositories.cart.save(cart);
    return this.summary(userId);
  },

  clear: function (userId) {
    SL.repositories.cart.remove(userId);
  },

  summary: function (userId) {
    var cart = SL.repositories.cart.get(userId);
    var totals = SL.services.pricing.computeCart(cart.items);
    var totalAfterPromo = SL.services.promo.applyPromo(totals.totalTTC, cart.promoCode);
    var count = cart.items.reduce(function (s, i) { return s + i.qty; }, 0);
    var weight = cart.items.reduce(function (s, i) { return s + (i.weight || 0) * i.qty; }, 0);
    return {
      items: cart.items,
      promoCode: cart.promoCode,
      count: count,
      weight: weight,
      subtotalHT: totals.subtotalHT,
      tva: totals.tva,
      totalBeforePromo: totals.totalTTC,
      totalTTC: totalAfterPromo
    };
  }
};
