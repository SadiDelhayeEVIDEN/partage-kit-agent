SL.repositories.cart = {
  get: function (userId) {
    var cart = SL.infra.storage.get('carts').find(function (c) { return c.userId === userId; });
    return cart || { userId: userId, items: [], promoCode: null, updatedAt: Date.now() };
  },
  save: function (cart) {
    var carts = SL.infra.storage.get('carts').filter(function (c) { return c.userId !== cart.userId; });
    cart.updatedAt = Date.now();
    carts.push(cart);
    SL.infra.storage.save('carts', carts);
  },
  remove: function (userId) {
    SL.infra.storage.save('carts', SL.infra.storage.get('carts').filter(function (c) { return c.userId !== userId; }));
  }
};
