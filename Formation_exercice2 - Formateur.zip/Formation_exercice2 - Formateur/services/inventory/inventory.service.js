SL.services.inventory = {
  getStock: function (productId) {
    return SL.repositories.inventory.getQty(productId);
  },

  decrement: function (productId, qty) {
    var next = SL.repositories.inventory.getQty(productId) - qty;
    SL.repositories.inventory.setQty(productId, next);
    if (next <= SL.shared.constants.LOW_STOCK_THRESHOLD) {
      SL.infra.bus.emit('stock.low', { productId: productId, qty: next }, 'inventory');
    }
  },

  increment: function (productId, qty) {
    SL.repositories.inventory.setQty(productId, SL.repositories.inventory.getQty(productId) + qty);
  },

  // Réserve le stock d'une commande
  reserveForOrder: function (order) {
    var self = this;
    order.items.forEach(function (i) { self.decrement(i.productId, i.qty); });
  },

  // Stock disponible = stock - commandes en attente
  available: function (productId) {
    var pending = SL.repositories.order.all().filter(function (o) { return o.status === 'PENDING'; });
    var reserved = 0;
    pending.forEach(function (o) {
      o.items.forEach(function (i) { if (i.productId == productId) reserved += i.qty; });
    });
    return this.getStock(productId) - reserved;
  },

  list: function () {
    var products = SL.repositories.catalog.all();
    return products.map(function (p) {
      var qty = SL.repositories.inventory.getQty(p.id);
      return {
        productId: p.id,
        name: p.name,
        image: p.image,
        qty: qty,
        available: SL.services.inventory.available(p.id),
        low: qty <= SL.shared.constants.LOW_STOCK_THRESHOLD
      };
    });
  },

  update: function (productId, qty) {
    qty = parseInt(qty, 10);
    if (isNaN(qty) || qty < 0) throw SL.helpers.httpError(400, 'Quantité invalide');
    SL.repositories.inventory.setQty(productId, qty);
    return { productId: Number(productId), qty: qty };
  }
};
