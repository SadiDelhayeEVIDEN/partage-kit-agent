SL.repositories.inventory = {
  all: function () {
    return SL.infra.storage.get('stock');
  },
  getQty: function (productId) {
    var row = this.all().find(function (r) { return r.productId == productId; });
    return row ? row.qty : 0;
  },
  setQty: function (productId, qty) {
    var rows = this.all();
    var row = rows.find(function (r) { return r.productId == productId; });
    if (row) row.qty = qty;
    else rows.push({ productId: Number(productId), qty: qty });
    SL.infra.storage.save('stock', rows);
  }
};
