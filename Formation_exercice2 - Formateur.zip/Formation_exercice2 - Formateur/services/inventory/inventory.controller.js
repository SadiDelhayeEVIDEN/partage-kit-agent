SL.controllers.inventory = {
  list: function () {
    return { status: 200, body: SL.services.inventory.list() };
  },
  update: function (req) {
    return { status: 200, body: SL.services.inventory.update(req.params.productId, (req.body || {}).qty) };
  }
};
