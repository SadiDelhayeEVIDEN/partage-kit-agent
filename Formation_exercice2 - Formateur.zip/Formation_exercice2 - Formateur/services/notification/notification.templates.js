SL.notificationTemplates = {
  'order.created': function (o) {
    return { subject: 'Commande #' + o.id + ' reçue', body: 'Nous avons bien reçu votre commande de ' + o.total + ' €.' };
  },
  'order.paid': function (o) {
    return { subject: 'Paiement confirmé - commande #' + o.id, body: 'Transaction ' + o.transactionId + '. Merci pour votre achat !' };
  },
  'order.failed': function (o) {
    return { subject: 'Problème de paiement - commande #' + o.id, body: 'Motif : ' + o.failureReason };
  },
  'order.shipped': function (o) {
    return { subject: 'Commande #' + o.id + ' expédiée', body: 'Votre colis est en route.' };
  },
  'stock.low': function (p) {
    return { subject: 'Stock bas : produit #' + p.productId, body: 'Il reste ' + p.qty + ' unité(s).' };
  }
};
