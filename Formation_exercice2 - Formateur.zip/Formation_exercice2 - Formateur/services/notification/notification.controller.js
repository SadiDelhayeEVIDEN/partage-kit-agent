SL.controllers.notification = {
  mine: function (req) {
    return { status: 200, body: SL.services.notification.listFor(req.user.email) };
  },
  all: function () {
    return { status: 200, body: SL.services.notification.listAll() };
  }
};
