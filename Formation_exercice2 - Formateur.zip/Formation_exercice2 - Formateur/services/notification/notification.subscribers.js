/*
 * Abonnements du service de notification aux événements métier.
 */
SL.services.notification.init = function () {
  function emailOf(userId) {
    var u = SL.repositories.user.findById(userId);
    return u ? u.email : 'inconnu';
  }

  SL.infra.bus.on('order.created', function (order) {
    SL.services.notification.send('order.created', emailOf(order.userId), order);
  }, 'notification');

  SL.infra.bus.on('order.paid', function (order) {
    SL.services.notification.send('order.paid', emailOf(order.userId), order);
  }, 'notification');

  SL.infra.bus.on('order.failed', function (order) {
    SL.services.notification.send('order.failed', emailOf(order.userId), order);
  }, 'notification');

  SL.infra.bus.on('order.shipped', function (order) {
    SL.services.notification.send('order.shipped', emailOf(order.userId), order);
  }, 'notification');

  SL.infra.bus.on('stock.low', function (data) {
    SL.services.notification.send('stock.low', SL.config.adminEmail, data);
  }, 'notification');
};
