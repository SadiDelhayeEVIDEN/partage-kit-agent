/*
 * Service de notifications (emails simulés, stockés dans la table "notifications").
 */
SL.services.notification = {
  send: function (type, to, payload) {
    var tpl = SL.notificationTemplates[type];
    if (!tpl) {
      SL.logger.warn('notification', 'Template inconnu : ' + type);
      return null;
    }
    var content = tpl(payload);
    var rows = SL.infra.storage.get('notifications');
    var notif = {
      id: SL.infra.storage.nextId('notifications'),
      type: type,
      to: to,
      subject: content.subject,
      body: content.body,
      at: Date.now()
    };
    rows.push(notif);
    SL.infra.storage.save('notifications', rows);
    SL.logger.info('notification', 'Email envoyé à ' + to + ' : ' + content.subject);
    return notif;
  },

  listFor: function (email) {
    return SL.infra.storage.get('notifications')
      .filter(function (n) { return n.to === email; })
      .sort(function (a, b) { return b.at - a.at; });
  },

  listAll: function () {
    return SL.infra.storage.get('notifications').sort(function (a, b) { return b.at - a.at; });
  }
};
