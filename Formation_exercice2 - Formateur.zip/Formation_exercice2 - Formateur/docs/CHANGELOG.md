# CHANGELOG

## 1.3.7 (2024-09)
- Hotfix : la livraison était facturée sur les grosses commandes.
- Ajout d'un rate-limit sur la gateway (demande de l'équipe sécurité).

## 1.3.0 (2023-11)
- Ajout de `shared/money.js` (utilisé par shipping, à généraliser).
- Code promo NOEL25.

## 1.2.0 (2022-03)
- Nouvelles constantes `shared/constants.js` (les anciennes restent pour compatibilité).
- Ajout du service analytics (lecture directe des commandes pour aller plus vite).

## 1.1.0 (2021-06)
- Début de la refonte avec conteneur d'injection de dépendances (`infrastructure/di-container.js`). En pause.
- Décommissionnement du CRM (fichiers conservés).

## 1.0.0 (2020-03)
- Découpage du monolithe en services + API Gateway + bus d'événements.
- Manifeste des services (`core/services-manifest.js`).

## 0.9 (2018)
- Première version (monolithe, `shared/utils/old-helpers.js`).
