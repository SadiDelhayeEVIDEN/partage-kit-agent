# Architecture ShopLegacy

> Document rédigé en 2019 lors du passage en "micro-services". Mis à jour partiellement en 2020.

## Vue d'ensemble

ShopLegacy est composé de micro-services indépendants qui communiquent **exclusivement** via l'API Gateway.

```
Frontend (Redux) --> API Gateway --> [ Catalog | Cart | Order | Payment | User | CRM ]
                                          |
                                     MySQL partagée
```

## Services

| Service  | Responsabilité                         | Base de données |
|----------|----------------------------------------|-----------------|
| Catalog  | Produits, catégories, stock            | `catalog_db`    |
| Cart     | Panier, calcul des prix                | `cart_db`       |
| Order    | Commandes, factures PDF                | `order_db`      |
| Payment  | Paiement Stripe, remboursements        | `payment_db`    |
| User     | Comptes, authentification JWT          | `user_db`       |
| CRM      | Synchronisation clients avec le CRM    | -               |

## Règles

1. Un service ne doit **jamais** appeler directement un autre service.
2. Les prix sont calculés **uniquement** par le service Cart.
3. Les mots de passe sont hashés avec bcrypt.
4. Toute la configuration est dans des variables d'environnement.
5. Chaque service a ses tests unitaires (couverture > 80 %).

## Événements

- `OrderCreated` -> envoi d'email (service Mailer)
- `OrderCanceled` -> remise en stock

## TODO

- [ ] Ajouter un service d'inventaire séparé
- [ ] Mettre en place un service de notifications
- [ ] Documenter le service Analytics
