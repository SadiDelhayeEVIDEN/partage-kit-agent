<#
  Exécute tests/index.html dans Edge/Chrome headless et affiche le résultat dans le terminal.
  Usage : powershell -ExecutionPolicy Bypass -File tools\run-tests.ps1
  Code de sortie : 0 si tous les tests passent, 1 sinon.
#>
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$candidates = @(
  "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
  "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
  "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
  "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe"
)
$browser = $candidates | Where-Object { $_ -and (Test-Path $_) } | Select-Object -First 1
if (-not $browser) { Write-Error 'Edge ou Chrome introuvable.'; exit 2 }

$url = 'file:///' + ((Join-Path $root 'tests\index.html') -replace '\\', '/')
$profileDir = Join-Path $env:TEMP ('shoplegacy-tests-' + [guid]::NewGuid())
$outFile = Join-Path $env:TEMP ('shoplegacy-tests-' + [guid]::NewGuid() + '.html')

$p = Start-Process -FilePath $browser -PassThru -RedirectStandardOutput $outFile -RedirectStandardError "$outFile.err" -ArgumentList @(
  '--headless', '--disable-gpu', '--no-first-run', "--user-data-dir=$profileDir",
  '--virtual-time-budget=10000', '--dump-dom', $url
)
if (-not $p.WaitForExit(60000)) { Stop-Process -Id $p.Id -Force; Write-Error 'Timeout'; exit 2 }

$dom = Get-Content $outFile -Raw -Encoding UTF8
Remove-Item $outFile, "$outFile.err" -ErrorAction SilentlyContinue
Remove-Item $profileDir -Recurse -Force -ErrorAction SilentlyContinue

function Strip($html) { (($html -replace '<[^>]+>', ' ') -replace '\s+', ' ').Trim() }

$summary = [regex]::Match($dom, '<div id="summary">([\s\S]*?)</div>').Groups[1].Value
Write-Host (Strip $summary)

$failures = [regex]::Matches($dom, '<div class="test fail">([\s\S]*?)</div></div>')
foreach ($f in $failures) { Write-Host ('  FAIL ' + (Strip $f.Groups[1].Value)) -ForegroundColor Red }

if ($failures.Count -gt 0 -or -not $summary) { exit 1 }
exit 0
