#!/usr/bin/env bash
# Exécute tests/index.html dans Chrome/Chromium/Edge headless (macOS / Linux).
# Usage : bash tools/run-tests.sh   — code de sortie 1 si au moins un test échoue.
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
for b in google-chrome chromium chromium-browser microsoft-edge \
  "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" \
  "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"; do
  if command -v "$b" >/dev/null 2>&1 || [ -x "$b" ]; then BROWSER="$b"; break; fi
done
[ -z "${BROWSER:-}" ] && { echo "Chrome/Edge introuvable"; exit 2; }

PROFILE="$(mktemp -d)"
DOM="$("$BROWSER" --headless --disable-gpu --no-first-run --user-data-dir="$PROFILE" \
  --virtual-time-budget=10000 --dump-dom "file://$ROOT/tests/index.html" 2>/dev/null)"
rm -rf "$PROFILE"

echo "$DOM" | tr -d '\n' | grep -o '<div id="summary">[^/]*</span>[^/]*</span>[^/]*</span>' | sed -e 's/<[^>]*>/ /g' -e 's/  */ /g'
FAILS="$(echo "$DOM" | tr -d '\n' | sed 's/<div class="test /\n&/g' | grep '^<div class="test fail">' | sed -e 's/<\/div><\/div>.*//' -e 's/<[^>]*>/ /g' -e 's/  */ /g')"
if [ -n "$FAILS" ]; then echo "$FAILS" | sed 's/^/  FAIL /'; exit 1; fi
exit 0
