# 🛒 ShopLegacy : reprendre un projet legacy avec l'IA

> **Exercice de montée en compétence.** Vous héritez de *ShopLegacy*, une boutique e-commerce « multi-services » développée entre 2018 et 2024 par des équipes successives. Elle fonctionne… à peu près. La documentation est obsolète, l'architecture s'est dégradée, il y a des bugs en production.
>
> Votre mission : **utiliser l'IA comme coéquipier** pour comprendre le projet, outiller votre assistant (instructions, **skills**, **agents**, **sous-agents**), corriger les bugs puis **refondre l'architecture**, sans rien casser.

---

## Sommaire

0. [Démarrage (aucune installation)](#0-démarrage-aucune-installation)
1. [Le projet en un coup d'œil](#1-le-projet-en-un-coup-dœil)
2. [Règles du jeu](#2-règles-du-jeu)
3. [Étape 1 : Découvrir le projet avec l'IA](#étape-1--découvrir-le-projet-avec-lia)
4. [Étape 2 : Écrire le fichier d'instructions du projet](#étape-2--écrire-le-fichier-dinstructions-du-projet)
5. [Étape 3 : Créer des skills](#étape-3--créer-des-skills)
6. [Étape 4 : Créer des agents spécialisés](#étape-4--créer-des-agents-spécialisés)
7. [Étape 5 : Orchestrer des sous-agents](#étape-5--orchestrer-des-sous-agents)
8. [Étape 6 : Chasse aux bugs](#étape-6--chasse-aux-bugs)
9. [Étape 7 : Refonte de l'architecture](#étape-7--refonte-de-larchitecture)
10. [Étape 8 : Livrables et grille d'évaluation](#étape-8--livrables-et-grille-dévaluation)
11. [Annexes](#annexes)

---

## 0. Démarrage (aucune installation)

Le projet est écrit en **HTML / CSS / JavaScript « vanilla »**. Il n'y a ni Node.js, ni npm, ni serveur : tout tourne dans le navigateur, et les « services » ainsi que leurs « bases de données » sont simulés en mémoire et dans le `localStorage`.

| Quoi | Comment |
|---|---|
| 🛍️ La boutique | Double-cliquez sur [`index.html`](index.html) |
| 🧭 La vue architecture | Double-cliquez sur [`architecture.html`](architecture.html) (ou lien « Architecture » dans l'en-tête) |
| 🧪 Les tests | Double-cliquez sur [`tests/index.html`](tests/index.html) |
| 🧪 Les tests en ligne de commande (pour l'IA) | Windows : `powershell -ExecutionPolicy Bypass -File tools\run-tests.ps1` · macOS/Linux : `bash tools/run-tests.sh` |

**Comptes de démo**

| Email | Mot de passe | Rôle |
|---|---|---|
| `alice@shop.fr` | `alice` | client |
| `bob@shop.fr` | `bob` | client |
| `admin@shop.fr` | `admin123` | administrateur |

**Cartes de test** : `4242 4242 4242 4242` (acceptée) · `4000 0000 0000 0000` (refusée). Au-delà de 1000 €, le paiement est refusé (anti-fraude).
**Codes promo** : `BIENVENUE10` (-10 %), `LEGACY5` (-5 €), `NOEL25` (expiré).

> 💡 Pour remettre les données à zéro : bouton **« Réinitialiser la base »** dans `architecture.html`.

**État initial attendu des tests** : `39 réussis · 3 échoués · 1 ignoré`. Les échecs sont **normaux** : ils font partie de l'exercice.

---

## 1. Le projet en un coup d'œil

```
.
├── index.html               # Boutique (charge ~60 scripts dans un ordre précis !)
├── architecture.html        # Graphe des services + journaux d'appels / événements
├── core/                    # namespace global SL, config, logger, seed, bootstrap, manifeste
├── shared/                  # constantes (x2 !), money, validators, utils/helpers.js ("god object")
├── infrastructure/          # stockage localStorage, bus d'événements, simulateur HTTP, DI (abandonné), PSP
├── gateway/                 # API Gateway : router, middlewares (logging, rate-limit, auth), routes
├── services/                # 10 "micro-services" : controller / service / repository / model
│   ├── user/  catalog/  inventory/  pricing/  cart/
│   ├── shipping/  order/  payment/  notification/  analytics/
│   └── legacy-crm/          # code mort
├── frontend/                # store, client API, composants, pages, vue architecture
├── tests/                   # mini-framework de test maison + tests unitaires / intégration
├── tools/                   # lanceurs de tests headless (PowerShell / bash)
└── docs/                    # ARCHITECTURE.md (obsolète !), CHANGELOG.md
```

**Flux théorique d'une requête** :

```
Page (frontend) → SL.api → SL.infra.http (latence simulée) → SL.gateway
   → middlewares (logging → rate-limit → auth) → router → controller → service → repository → localStorage
                                                              ↘ SL.infra.bus.emit('order.created') → abonnés
```

En pratique, beaucoup de services s'appellent **directement** (`SL.services.x.y()`), lisent les tables des autres, ou passent par la gateway quand ça les arrange. À vous de le découvrir.

---

## 2. Règles du jeu

1. **Zéro installation** : pas de npm, pas de framework, pas de bundler. Le projet doit toujours s'ouvrir en double-cliquant (`file://`). Les modules ES (`import`/`export`) sont **bloqués** en `file://` : gardez des `<script>` classiques.
2. **L'IA propose, vous disposez** : relisez chaque modification. Toute affirmation de l'IA (« ce fichier n'est pas utilisé », « ce bug vient de… ») doit être **vérifiée** dans le code ou par un test.
3. **Petits pas** : une modification = un objectif. Lancez les tests après chaque étape.
4. **Tests d'abord** : pour chaque bug, écrivez un test qui échoue *avant* de corriger.
5. **Tracez votre travail** : conservez vos meilleurs prompts dans `docs/PROMPTS.md`.
6. **Outil au choix** : GitHub Copilot, Claude Code, Cursor, Codex, Gemini CLI… Les concepts sont les mêmes. L'[annexe A](#annexe-a--où-placer-les-fichiers-selon-loutil) indique où placer les fichiers selon l'outil.

> ⚠️ Si votre outil travaille sur un dépôt Git, faites `git init` puis un commit initial **avant** de commencer. Cela vous permettra de revenir en arrière facilement.

---

## Étape 1 : Découvrir le projet avec l'IA

**Objectif** : construire une compréhension fiable du projet **sans tout lire vous-même**, et apprendre à vérifier ce que l'IA affirme.

### 1.1 Exploration guidée

Ouvrez le dossier dans votre IDE ou votre CLI avec l'assistant IA, puis essayez ces prompts (adaptez-les) :

```text
Tu découvres ce projet. Sans rien modifier, explique-moi :
1. comment l'application démarre (ordre de chargement, bootstrap),
2. le chemin complet d'une requête "ajouter au panier", du clic jusqu'au localStorage,
3. la liste des services et leurs responsabilités.
Cite les fichiers et les lignes pour chaque affirmation.
```

```text
Liste toutes les dépendances RÉELLES entre services en cherchant dans le code
les appels SL.services.*, SL.repositories.*, SL.infra.http.request et SL.infra.bus.emit/on.
Produis un tableau "service appelant → service appelé → type (direct / HTTP / événement / accès BDD) → fichier:ligne".
```

```text
Compare ce que tu as trouvé avec core/services-manifest.js et docs/ARCHITECTURE.md.
Quelles différences ? Quels cycles de dépendances existent réellement ?
```

### 1.2 Vérifiez l'IA

- Ouvrez `architecture.html`, lancez les deux scénarios et comparez le graphe aux réponses de l'IA.
- Choisissez **3 affirmations** de l'IA et vérifiez-les vous-même dans le code. Notez celles qui étaient fausses ou incomplètes.

### ✅ Livrable étape 1

`docs/DISCOVERY.md` contenant :
- un diagramme **Mermaid** des dépendances réelles (demandez-le à l'IA, puis corrigez-le),
- la liste des écarts entre la doc, le manifeste et le code,
- vos 3 vérifications (vrai / faux / partiellement vrai).

---

## Étape 2 : Écrire le fichier d'instructions du projet

**Objectif** : donner à l'IA un **contexte permanent** pour qu'elle respecte les conventions du projet à chaque requête.

Les outils lisent automatiquement un fichier d'instructions à la racine. Le standard le plus portable est **`AGENTS.md`** ; voir l'[annexe A](#annexe-a--où-placer-les-fichiers-selon-loutil) pour les équivalents propres à chaque outil.

### 2.1 Générez un premier jet

```text
À partir de ton analyse, rédige un fichier AGENTS.md (max 80 lignes) pour ce dépôt qui contienne :
- le but du projet et la contrainte "zéro installation / file://",
- l'architecture (couches, namespace SL, ordre de chargement des scripts),
- les conventions (nommage des fichiers *.service.js, *.controller.js, *.repository.js, erreurs via SL.helpers.httpError, etc.),
- comment lancer les tests (navigateur + tools/run-tests.*),
- les pièges connus (3 fichiers HTML listent les scripts, constantes en double, etc.),
- les règles pour l'IA : ne jamais ajouter de dépendance npm, toujours lancer les tests, petits changements.
Ne mets que des informations vérifiables dans le code.
```

### 2.2 Affinez

- Retirez tout ce qui est générique (« écrire du code propre ») : ça n'apporte rien.
- Ajoutez ce que **vous** avez appris et que l'IA ne pouvait pas deviner.
- Testez : ouvrez une **nouvelle session** et demandez « Comment ajouter un nouveau service ? ». La réponse respecte-t-elle vos conventions ?

### ✅ Livrable étape 2

`AGENTS.md` (ou l'équivalent pour votre outil), relu et testé.

---

## Étape 3 : Créer des skills

**Objectif** : capturer des **savoir-faire réutilisables** que l'IA chargera uniquement quand c'est pertinent.

Une **skill** est un dossier contenant un fichier `SKILL.md` : un en-tête YAML (`name`, `description`), puis des instructions pas à pas. Le dossier peut aussi contenir des scripts ou des modèles. La `description` est cruciale : c'est elle qui permet à l'IA de décider **quand** charger la skill.

### 3.1 Exemple de structure

```markdown
---
name: write-shoplegacy-test
description: Écrire ou modifier un test pour ShopLegacy avec le mini-framework maison (tests/lib). À utiliser dès qu'il faut ajouter un test unitaire ou d'intégration, reproduire un bug ou valider une correction.
---

# Écrire un test ShopLegacy

## Où
- Tests unitaires : `tests/unit/<domaine>.test.js`
- Tests d'intégration (via la gateway) : `tests/integration/<parcours>.test.js`
- Tout nouveau fichier DOIT être ajouté dans `tests/index.html` (section correspondante).

## API disponible
- `describe`, `it`, `xit`, `beforeEach`, `expect(x).toBe / toEqual / toBeCloseTo / toThrow / toHaveLength / toHaveDecimalsAtMost / not...`
- `Fixtures.resetDb()`, `Fixtures.login()`, `Fixtures.api(method, url, body, token)`, `Fixtures.validCard`

## Procédure
1. Appeler `Fixtures.resetDb()` dans `beforeEach` si le test touche aux données.
2. Pour un appel API, retourner la Promise : `return Fixtures.api(...).then(...)`.
3. Lancer `tools/run-tests.ps1` (ou `.sh`) et vérifier que le nouveau test échoue pour la bonne raison avant de corriger.

## Exemple
(…un exemple complet…)
```

### 3.2 Skills à créer (au minimum 4)

| Skill | Rôle |
|---|---|
| `run-tests` | Lancer la suite (navigateur ou headless), interpréter la sortie, décider si c'est vert. |
| `write-shoplegacy-test` | Écrire un test avec le framework maison (exemple ci-dessus). |
| `map-dependencies` | Procédure pour extraire les dépendances réelles d'un service (motifs `grep`, format du tableau de sortie, mise à jour du Mermaid). |
| `refactor-service` | Check-list pour modifier un service sans régression : ordre des scripts dans les **3** fichiers HTML, contrat de la gateway, événements émis, tests. |

Bonus : `add-service` (créer un service complet : model / repository / service / controller / routes / manifeste / tests).

### 3.3 Faites générer, puis testez

```text
Crée une skill "map-dependencies" pour ce projet, au format SKILL.md avec un front-matter name/description.
Elle doit décrire une procédure reproductible (commandes de recherche, format de sortie Markdown + Mermaid).
Base-toi sur la façon dont tu as réellement trouvé les dépendances à l'étape 1.
```

Ensuite, **dans une nouvelle session**, posez une question qui devrait déclencher la skill (par exemple « Quelles sont les dépendances du service order ? »). Vérifiez qu'elle est bien chargée. Sinon, améliorez sa `description`.

### ✅ Livrable étape 3

Au moins 4 skills, chacune testée en situation (notez le prompt de test dans `docs/PROMPTS.md`).

---

## Étape 4 : Créer des agents spécialisés

**Objectif** : définir des **agents** (aussi appelés *custom agents* ou *subagents* selon les outils). Chacun a un rôle, des instructions, un périmètre d'outils et éventuellement un modèle dédiés.

Un agent est en général un fichier Markdown avec un en-tête YAML :

```markdown
---
name: bug-hunter
description: Traque les bugs fonctionnels de ShopLegacy. À utiliser pour analyser un symptôme, le reproduire par un test, puis proposer un correctif minimal.
tools: [read, search, edit, terminal]   # selon l'outil
---

Tu es un développeur senior spécialisé dans le débogage d'applications legacy.

## Méthode obligatoire
1. Reformuler le symptôme et formuler 2-3 hypothèses.
2. Localiser le code en cause (fichier:ligne).
3. Écrire un test qui échoue (skill write-shoplegacy-test).
4. Appliquer le correctif MINIMAL. Ne pas refactorer au passage.
5. Lancer la suite complète (skill run-tests) et rapporter le résultat.

## Interdits
- Modifier un test existant pour le faire passer, sauf s'il est prouvé faux.
- Ajouter une dépendance externe.
```

### 4.1 Agents à créer

| Agent | Rôle | Outils conseillés |
|---|---|---|
| `architect` | Analyse l'architecture, détecte couplages et cycles, propose des cibles et des **ADR**. **Lecture seule.** | lecture, recherche |
| `bug-hunter` | Méthode symptôme → test rouge → correctif → test vert. | lecture, édition, terminal |
| `test-writer` | Augmente la couverture des zones non testées (notification, analytics, payment, inventory…). | lecture, édition, terminal |
| `reviewer` | Relit un diff : régressions, sécurité, respect d'`AGENTS.md`. **Ne modifie rien.** | lecture, recherche |
| `security-auditor` *(bonus)* | Secrets, mots de passe, données de carte, contrôles d'accès. | lecture, recherche |

> 💡 **Principe du moindre privilège** : un agent qui analyse ne doit pas pouvoir éditer. Un agent qui relit ne doit pas pouvoir corriger son propre travail.

### 4.2 Faites générer les agents par l'IA

```text
Crée un agent "architect" pour ce projet (fichier agent au format de mon outil).
Il est en lecture seule, connaît les contraintes d'AGENTS.md, utilise la skill map-dependencies,
et produit ses recommandations sous forme d'ADR (docs/adr/NNN-titre.md : contexte, décision, conséquences).
```

### 4.3 Testez chaque agent

- Invoquez `reviewer` sur une modification volontairement mauvaise (par exemple un `console.log` oublié ou une clé API ajoutée). La détecte-t-il ?
- Invoquez `architect` : « Quels sont les 3 couplages les plus dangereux ? ». Ses réponses sont-elles sourcées (fichier:ligne) ?

### ✅ Livrable étape 4

Au moins 4 agents, avec pour chacun un exemple d'invocation et le résultat obtenu (dans `docs/PROMPTS.md`).

---

## Étape 5 : Orchestrer des sous-agents

**Objectif** : apprendre à **déléguer** une tâche large à plusieurs sous-agents qui travaillent dans des **contextes séparés** (souvent en parallèle), puis agréger leurs résultats.

Pourquoi ? Auditer 10 services dans une seule conversation sature le contexte : l'IA « oublie » le début et mélange les services. Avec des sous-agents, chaque service est audité dans un contexte propre, et l'orchestrateur ne reçoit que des **rapports synthétiques**.

### 5.1 Créez un agent orchestrateur

```markdown
---
name: audit-orchestrator
description: Lance un audit complet de ShopLegacy en déléguant un sous-agent par service, puis consolide les résultats.
---

1. Lister les dossiers de services/ (ignorer legacy-crm sauf pour le code mort).
2. Pour CHAQUE service, déléguer à un sous-agent "architect" (en parallèle si possible) avec la consigne :
   "Audite UNIQUEMENT services/<nom>. Rends un rapport de 15 lignes max au format :
    dépendances sortantes (type + fichier:ligne), données d'autres services lues/écrites,
    événements émis/écoutés, duplications, suspicions de bug, risques sécurité."
3. Agréger les rapports dans docs/AUDIT.md : tableau de synthèse, matrice de dépendances, top 10 des problèmes priorisés.
4. Ne JAMAIS modifier le code.
```

### 5.2 Exercices

1. **Audit parallèle** : lancez l'orchestrateur. Comparez `docs/AUDIT.md` avec votre `DISCOVERY.md` de l'étape 1. Qu'a-t-il trouvé en plus ?
2. **Pipeline séquentiel** : créez un flux `bug-hunter` → `reviewer` → (si refus) retour à `bug-hunter`. Appliquez-le à un bug de l'étape 6.
3. **Contrôle croisé** : faites auditer le **même** service par deux sous-agents avec des modèles différents (si votre outil le permet). Où divergent-ils ?

> 🎯 Points d'attention : un sous-agent ne voit **pas** votre conversation. Son prompt doit donc être **autonome** (contexte, périmètre, format de sortie, critère d'arrêt). C'est la principale source d'échec.

### ✅ Livrable étape 5

`docs/AUDIT.md` généré par l'orchestrateur, plus un court retour d'expérience (5 lignes) : avantages, limites, coût.

---

## Étape 6 : Chasse aux bugs

**Objectif** : trouver et corriger les bugs avec la méthode **symptôme → hypothèse → test rouge → correctif minimal → tests verts**, en vous appuyant sur vos agents et skills.

Voici les **symptômes** rapportés par le support et les utilisateurs. À vous de trouver les causes.

| # | Symptôme rapporté | Où l'observer | Indice |
|---|---|---|---|
| B1 | « Le total de ma commande affiche **58.31027999999999 €** » | Mes commandes, Back-office | Comment sont stockés les montants ? |
| B2 | « Avec BIENVENUE10, j'ai payé **moins** que le total affiché dans le panier. » (le marketing est furieux) | Panier puis commande | Combien de fois la promo est-elle appliquée ? |
| B3 | « Après un paiement refusé, le **stock a quand même baissé**. » | Back-office > Stock, carte `4000…` | Ordre des opérations dans le checkout |
| B4 | « Je reçois **deux emails** "Commande reçue" pour chaque commande. » | Boîte mail | Qui s'abonne aux événements, et combien de fois ? |
| B5 | « Un livre affiché **34,29 €** dans le catalogue coûte **39,00 €** dans le panier. » | Catalogue vs Panier (Clean Code) | Il y a deux tables de TVA… |
| B6 | « Il n'y a que **7 produits par page** et certains produits n'apparaissent jamais. » | Catalogue, pagination | Bornes d'un `slice` |
| B7 | « Le bouton **Retirer** du panier ne fait rien. » | Panier | Type de l'identifiant venant du DOM/URL |
| B8 | « Le panier annonce la livraison **offerte** pour 50 €, mais elle est **facturée** à la commande. » | Panier vs commande, total ≈ 50 € | Deux implémentations de la même règle |
| B9 | « Après un moment d'utilisation, tout renvoie **"Trop de requêtes"** et il faut recharger la page. » | N'importe où (≈100 requêtes) | Unité de temps |
| B10 | « **Alice** (cliente) voit le **Back-office** et peut modifier le stock ! » 🔥 | Connecté en Alice | Lisez très attentivement `isAdmin` |
| B11 | « Le chiffre d'affaires du dashboard est **toujours à 0 €**. » | Back-office | Quelle constante de statut est utilisée ? |

**Bonus (non listés)** : il reste au moins 5 autres défauts (données sensibles stockées ou renvoyées, erreurs avalées, panier invité perdu à la connexion, stock pouvant devenir négatif, annulation de commande sans remise en stock…). Faites-les trouver par votre agent `security-auditor` ou par l'orchestrateur.

### 6.1 Démarche attendue (exemple)

```text
@bug-hunter Symptôme B7 : le bouton "Retirer" du panier ne fait rien.
Suis ta méthode : hypothèses, localisation fichier:ligne, test rouge, correctif minimal, run-tests.
```

### 6.2 Attention aux tests existants

- **3 tests échouent** dès le départ : ils correspondent à de vrais bugs.
- **Un test passe alors qu'il valide un bug** (un « test menteur »). Trouvez-le et corrigez-le. Demandez-vous aussi pourquoi l'IA risque de le « corriger » dans le mauvais sens.
- Un test est marqué `xit` (TODO) : implémentez-le.

### ✅ Livrable étape 6

- Les 11 bugs corrigés, chacun couvert par **au moins un test** qui échouait avant la correction.
- Tous les tests au vert (`tools/run-tests.*` renvoie 0).
- Un tableau dans `docs/BUGS.md` : bug, cause racine, fichier:ligne, test ajouté, agent/prompt utilisé.

---

## Étape 7 : Refonte de l'architecture

**Objectif** : faire évoluer l'architecture vers une cible saine, **de façon incrémentale**, en gardant l'application fonctionnelle et les tests verts à chaque étape.

### 7.1 Dette technique connue (extraits)

| # | Problème | Exemples |
|---|---|---|
| D1 | Namespace global et ordre de chargement fragile | `window.SL`, variables globales (`TVA_RATES`, `PAGE_SIZE`, `STATUS_PAID`) |
| D2 | Liste des scripts **dupliquée 3 fois** | `index.html`, `architecture.html`, `tests/index.html` |
| D3 | Appels directs entre services, en contournant la gateway | `cart → catalog`, `order → payment`, `catalog → inventory`… |
| D4 | **Dépendances circulaires** | `order ↔ payment`, `order → inventory → order (repository)` |
| D5 | Services qui lisent les données des autres | `analytics` lit `orders`, `inventory` lit `orders`, `helpers.getCurrentUser` lit `sessions` et `users` |
| D6 | Logique dupliquée | TVA (helpers vs pricing.rules), règle de livraison (front vs back), validation d'email (x2), constantes (x2) |
| D7 | Sécurité | clé API en dur et loggée, mots de passe en clair, numéros de carte stockés, mot de passe renvoyé au login, frontend qui appelle `SL.services.auth` directement |
| D8 | Code mort | `old-helpers.js`, `legacy-crm/`, `di-container.js`, `order.events.js`, `shipping.rates.js` |
| D9 | Erreurs avalées | `event-bus.js` (`catch {}`), `logger` |
| D10 | Montants en flottants | partout sauf `shipping` (`shared/money.js` existe mais n'est pas utilisé) |
| D11 | Documentation et manifeste faux | `docs/ARCHITECTURE.md`, `core/services-manifest.js` |
| D12 | Styles mélangés sync/async | `order` appelle `shipping` en HTTP mais tous les autres en direct |

### 7.2 Architecture cible proposée (à discuter, puis à formaliser en ADR)

- **Frontières claires** : chaque service expose un **contrat** (objet `api` public). Ses `repository` sont **privés**, et seul ce service accède à ses tables.
- **Communication** :
  - requêtes synchrones (lecture) : uniquement via la **gateway** (ou un client de service unique et injecté),
  - effets de bord entre domaines : uniquement via le **bus d'événements** (par exemple `payment.succeeded` / `payment.failed` → `order` met à jour son statut, `inventory` libère le stock). Cela casse les cycles (pattern *saga*).
- **Une seule source de vérité** : constantes, TVA, règles de livraison et calculs monétaires (en centimes ou via `money`).
- **Composition explicite** : un **registre de modules** (ou le DI existant terminé) qui déclare les dépendances, détecte les cycles et **génère** le manifeste. Fini le manifeste maintenu à la main.
- **Liste des scripts centralisée** (un seul fichier de chargement réutilisé par les 3 pages).
- **Sécurité** : plus de secrets dans le code client, plus de mots de passe en clair (au minimum hachés, même de façon simulée), plus de numéros de carte stockés, contrôle `isAdmin` côté gateway uniquement.

### 7.3 Démarche guidée par l'IA

1. **Planifier avant d'agir** : utilisez le **mode plan** de votre outil, s'il existe, ou demandez explicitement un plan sans modification :
   ```text
   @architect À partir de docs/AUDIT.md et de la cible de la section 7.2, propose un plan de refonte en
   8 à 12 étapes INDÉPENDAMMENT LIVRABLES. Pour chaque étape : objectif, fichiers touchés, risques,
   tests à ajouter AVANT, critère de fin. L'application doit rester fonctionnelle (file://) après chaque étape.
   Rédige une ADR pour chaque décision structurante.
   ```
2. **Relire et challenger le plan** : demandez à un autre agent (ou un autre modèle) de le critiquer.
3. **Exécuter étape par étape** : un agent d'implémentation (ou vous) réalise une étape, puis `reviewer` relit le diff, puis `run-tests`. **Commit** à chaque étape verte.
4. **Paralléliser quand c'est possible** : une fois les contrats définis, des sous-agents peuvent migrer plusieurs services en parallèle (un service par sous-agent). Attention aux fichiers partagés (`index.html`, `routes.js`) : désignez un seul responsable pour ces fichiers.
5. **Mesurer** : à la fin, relancez l'orchestrateur d'audit et comparez avec le premier `AUDIT.md`.

### 7.4 Critères de réussite de la refonte

- [ ] Aucun cycle de dépendances. Le graphe d'`architecture.html` est **généré** depuis le code ou le registre, et non maintenu à la main.
- [ ] Aucun service n'accède au repository ou à la table d'un autre service.
- [ ] Une seule définition par règle métier (TVA, livraison, promo, statuts).
- [ ] Aucun secret, mot de passe en clair ou numéro de carte dans le stockage ou les logs.
- [ ] Code mort supprimé (justifié par une recherche d'usages).
- [ ] Liste des scripts non dupliquée.
- [ ] `docs/ARCHITECTURE.md` réécrit et à jour, avec un diagramme Mermaid.
- [ ] Tous les tests verts. Couverture ajoutée sur notification, payment, inventory et analytics.
- [ ] L'application fonctionne toujours en double-cliquant sur `index.html`.

---

## Étape 8 : Livrables et grille d'évaluation

### Livrables

| Fichier | Étape |
|---|---|
| `docs/DISCOVERY.md` | 1 |
| `AGENTS.md` (ou équivalent) | 2 |
| Dossier de skills (≥ 4) | 3 |
| Dossier d'agents (≥ 4 + orchestrateur) | 4-5 |
| `docs/AUDIT.md` (avant / après) | 5, 7 |
| `docs/BUGS.md` + tests | 6 |
| `docs/adr/*.md` + code refondu + `docs/ARCHITECTURE.md` | 7 |
| `docs/PROMPTS.md` : vos meilleurs prompts et ce que vous avez appris | toutes |

### Grille d'évaluation (sur 100)

| Critère | Points |
|---|---|
| Qualité de la découverte (exactitude, vérification des dires de l'IA) | 10 |
| Fichier d'instructions : concis, spécifique, vérifiable | 10 |
| Skills : descriptions déclenchantes, procédures reproductibles, testées | 15 |
| Agents : rôles distincts, moindre privilège, testés | 15 |
| Orchestration de sous-agents : prompts autonomes, agrégation utile | 10 |
| Bugs : 11/11 corrigés avec tests, cause racine expliquée | 20 |
| Refonte : critères 7.4 atteints, ADR, démarche incrémentale | 15 |
| Esprit critique : erreurs de l'IA identifiées et documentées | 5 |

---

## Annexes

### Annexe A : où placer les fichiers selon l'outil

> Les conventions évoluent vite : vérifiez la documentation de votre outil. En cas de doute, **`AGENTS.md`** à la racine est lu par la plupart des agents.

| Outil | Instructions projet | Skills | Agents / sous-agents |
|---|---|---|---|
| **GitHub Copilot** (VS Code, CLI, coding agent) | `.github/copilot-instructions.md` ou `AGENTS.md` (+ `.github/instructions/*.instructions.md`) | `.github/skills/<nom>/SKILL.md` | `.github/agents/<nom>.agent.md` |
| **Claude Code** | `CLAUDE.md` | `.claude/skills/<nom>/SKILL.md` | `.claude/agents/<nom>.md` |
| **Cursor** | `AGENTS.md` ou `.cursor/rules/*.mdc` | selon version (règles « agent requested ») | selon version |
| **OpenAI Codex CLI** | `AGENTS.md` | voir la documentation (support récent) | selon version |
| **Gemini CLI** | `GEMINI.md` | extensions | selon version |

Le format `SKILL.md` (front-matter `name` + `description`, puis des instructions) est commun à la plupart des outils. Si le vôtre n'a pas de notion de skill, placez ces procédures dans `docs/skills/` et référencez-les depuis votre fichier d'instructions.

### Annexe B : bonnes pratiques et pièges

- ✅ **Demandez des sources** (`fichier:ligne`) : cela réduit fortement les hallucinations.
- ✅ **Contexte minimal et ciblé** : mieux vaut une skill chargée à la demande qu'un `AGENTS.md` de 500 lignes.
- ✅ **Nouvelle session = test réel** de vos instructions, skills et agents.
- ✅ **Faites relire par un autre agent ou modèle** que celui qui a écrit le code.
- ⚠️ L'IA a tendance à **modifier les tests pour les faire passer** : interdisez-le explicitement.
- ⚠️ L'IA « nettoie » volontiers au passage : exigez des **diffs minimaux** pour les corrections de bugs.
- ⚠️ L'IA peut proposer **npm, des modules ES ou un framework** : rappelez la contrainte `file://`.
- ⚠️ Un fichier peut **sembler** mort et être chargé quand même (ou l'inverse) : vérifiez les balises `<script>` des 3 fichiers HTML.
- ⚠️ Le `localStorage` persiste : en cas de comportement étrange, réinitialisez la base.

### Annexe C : corrigé formateur

<details>
<summary>⚠️ Spoilers : causes des bugs (réservé au formateur)</summary>

| # | Fichier | Cause | Correction attendue |
|---|---|---|---|
| B1 | `services/pricing/pricing.service.js`, `services/order/order.service.js`, `frontend/pages/orders-page.js` | Montants flottants jamais arrondis ; affichage brut `o.total + ' €'` | Utiliser `SL.shared.money` (arrondi au centime) pour les calculs et `formatPrice` à l'affichage |
| B2 | `services/order/order.service.js` (`checkout`) | `applyPromo` appliqué sur `cart.totalTTC`, qui est **déjà** remisé par `cart.summary` | Utiliser `cart.totalTTC` directement |
| B3 | `services/order/order.service.js` | Stock décrémenté (`reserveForOrder`) **avant** le paiement et jamais restauré en cas d'échec | Décrémenter après le succès, ou restaurer sur `order.failed` (événement) |
| B4 | `frontend/app.js` (`start`) + `core/bootstrap.js` | `notification.init()` appelé deux fois, ce qui crée des abonnements en double | Supprimer l'appel dans `app.js` et rendre `init` idempotent |
| B5 | `services/pricing/pricing.rules.js` + `shared/constants-old.js` | `TVA_RATES` utilise la clé `book` alors que la catégorie est `books`, donc TVA à 20 % ; le catalogue utilise les nouvelles constantes | Utiliser `SL.shared.constants.TVA` partout. Corriger aussi le **test menteur** « applique la TVA par défaut (20 %) aux livres » dans `tests/unit/pricing.test.js` |
| B6 | `services/catalog/catalog.repository.js` (`paginate`) | `end = start + size - 1` avec `slice` (borne exclusive) | `end = start + size` |
| B7 | `services/cart/cart.service.js` (`removeItem`) | `productId` reçu en **string** (paramètre d'URL) comparé avec `!==` à un nombre | Normaliser `Number(productId)` dans le controller ou le service |
| B8 | `services/shipping/shipping.service.js` | `subtotal > freeThreshold` au lieu de `>=` (et règle dupliquée côté front dans `cart-page.js`) | `>=` et une seule source (appel API `/api/shipping/quote` côté front) |
| B9 | `core/config.js` | `rateWindowMs: 60 * 1000 * 1000` (≈ 16 h) au lieu de 60 000 ms | `60 * 1000` |
| B10 | `services/user/auth.service.js` (`isAdmin`) | Affectation `user.role = 'admin'` au lieu d'une comparaison ; tout utilisateur devient admin (et l'objet est muté) | `user.role === 'admin'`. Ajouter le test `xit` de `auth.test.js` |
| B11 | `services/analytics/analytics.service.js` | Compare à `STATUS_PAID` (`'paid'`, ancienne constante) alors que les commandes ont `'PAID'` | `SL.shared.constants.ORDER_STATUS.PAID` |

**Défauts bonus** : mot de passe renvoyé par `/api/auth/login` (`user.controller.js`) ; mots de passe en clair (`seed.js`, `user.service.js`) ; numéro de carte complet stocké (`payment.service.js`) et affiché dans le back-office ; clé API loggée (`payment-provider.js`) ; erreurs avalées dans le bus ; panier `guest` non fusionné à la connexion ; stock pouvant devenir négatif ; `updateStatus('CANCELLED')` ne remet pas en stock et émet `order.cancelled`, alors que la doc annonce `order.canceled` ; panier vidé même si le paiement échoue ; `old-helpers.js` utilise une TVA de 19,6 %.

</details>

---

*Bon courage. Et rappelez-vous : l'IA écrit vite, mais c'est vous qui signez le commit.* 🚀
