/*
 * API Gateway : point d'entrée unique (en théorie) de tous les services.
 * Pipeline : parse URL -> match route -> middlewares -> handler du controller.
 */
SL.gateway = {
  middlewares: [],

  use: function (name, fn) {
    this.middlewares.push({ name: name, fn: fn });
  },

  handle: function (req) {
    var parsed = SL.gateway.router.parse(req.url);
    req.path = parsed.path;
    req.query = parsed.query;

    var match = SL.gateway.router.match(req.method, req.path);
    if (!match) {
      return { status: 404, body: { error: 'Route introuvable : ' + req.method + ' ' + req.path }, service: 'gateway' };
    }
    req.params = match.params;
    req.route = match.route;

    for (var i = 0; i < this.middlewares.length; i++) {
      var early = this.middlewares[i].fn(req);
      if (early) {
        early.service = 'gateway';
        return early;
      }
    }

    var service = match.route.service;
    try {
      var out = match.route.handler(req);
      return Promise.resolve(out).then(function (res) {
        res = res || { status: 204, body: null };
        res.service = service;
        return res;
      }, function (err) {
        return SL.gateway._error(err, service);
      });
    } catch (err) {
      return SL.gateway._error(err, service);
    }
  },

  _error: function (err, service) {
    if (!err.status || err.status >= 500) SL.logger.error('gateway', err.message, err.stack);
    return {
      status: err.status || 500,
      body: { error: err.status ? err.message : 'Erreur interne du serveur' },
      service: service
    };
  }
};
