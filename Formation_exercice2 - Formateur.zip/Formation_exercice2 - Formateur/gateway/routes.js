/*
 * Table de routage : URL -> controller.
 */
(function () {
  var r = SL.gateway.router;
  var c = SL.controllers;

  // Auth / utilisateurs
  r.add('POST', '/api/auth/login', 'user', function (req) { return c.user.login(req); });
  r.add('POST', '/api/auth/register', 'user', function (req) { return c.user.register(req); });
  r.add('POST', '/api/auth/logout', 'user', function (req) { return c.user.logout(req); }, { auth: true });
  r.add('GET', '/api/auth/me', 'user', function (req) { return c.user.me(req); }, { auth: true });

  // Catalogue
  r.add('GET', '/api/products', 'catalog', function (req) { return c.catalog.list(req); });
  r.add('GET', '/api/products/:id', 'catalog', function (req) { return c.catalog.get(req); });
  r.add('GET', '/api/categories', 'catalog', function (req) { return c.catalog.categories(req); });

  // Panier
  r.add('GET', '/api/cart', 'cart', function (req) { return c.cart.get(req); });
  r.add('POST', '/api/cart/items', 'cart', function (req) { return c.cart.addItem(req); });
  r.add('DELETE', '/api/cart/items/:productId', 'cart', function (req) { return c.cart.removeItem(req); });
  r.add('POST', '/api/cart/promo', 'cart', function (req) { return c.cart.setPromo(req); });

  // Prix / promo
  r.add('GET', '/api/promo/:code', 'pricing', function (req) { return c.pricing.checkPromo(req); });

  // Livraison
  r.add('GET', '/api/shipping/quote', 'shipping', function (req) { return c.shipping.quote(req); });

  // Commandes
  r.add('POST', '/api/orders/checkout', 'order', function (req) { return c.order.checkout(req); }, { auth: true });
  r.add('GET', '/api/orders', 'order', function (req) { return c.order.mine(req); }, { auth: true });
  r.add('GET', '/api/admin/orders', 'order', function (req) { return c.order.all(req); }, { auth: true, admin: true });
  r.add('PUT', '/api/admin/orders/:id/status', 'order', function (req) { return c.order.updateStatus(req); }, { auth: true, admin: true });

  // Paiements
  r.add('GET', '/api/admin/payments', 'payment', function (req) { return c.payment.list(req); }, { auth: true, admin: true });

  // Stock
  r.add('GET', '/api/admin/inventory', 'inventory', function (req) { return c.inventory.list(req); }, { auth: true, admin: true });
  r.add('PUT', '/api/admin/inventory/:productId', 'inventory', function (req) { return c.inventory.update(req); }, { auth: true, admin: true });

  // Notifications
  r.add('GET', '/api/notifications', 'notification', function (req) { return c.notification.mine(req); }, { auth: true });
  r.add('GET', '/api/admin/notifications', 'notification', function (req) { return c.notification.all(req); }, { auth: true, admin: true });

  // Analytics
  r.add('GET', '/api/admin/dashboard', 'analytics', function (req) { return c.analytics.dashboard(req); }, { auth: true, admin: true });
})();
