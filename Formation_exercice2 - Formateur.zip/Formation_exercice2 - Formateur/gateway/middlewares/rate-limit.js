/*
 * Middleware de limitation de débit (rate limiting).
 * Le compteur est remis à zéro à chaque fenêtre.
 */
(function () {
  var counter = 0;

  setInterval(function () {
    counter = 0;
  }, SL.config.gateway.rateWindowMs);

  SL.gateway.use('rate-limit', function (req) {
    counter++;
    if (counter > SL.config.gateway.rateLimit) {
      SL.logger.warn('rate-limit', 'Trop de requêtes (' + counter + ')');
      return { status: 429, body: { error: 'Trop de requêtes, réessayez plus tard' } };
    }
  });

  SL.gateway._resetRateLimit = function () { counter = 0; };
})();
