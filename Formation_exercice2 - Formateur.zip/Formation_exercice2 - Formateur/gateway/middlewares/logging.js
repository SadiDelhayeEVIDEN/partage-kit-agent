/*
 * Middleware de logs.
 */
SL.gateway.use('logging', function (req) {
  SL.logger.debug('gateway', req.method + ' ' + req.url, { caller: req.headers['x-caller'] });
});
