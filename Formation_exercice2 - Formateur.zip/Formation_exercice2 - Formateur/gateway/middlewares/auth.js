/*
 * Middleware d'authentification.
 * - attache req.user si un token valide est présent
 * - bloque les routes "auth" sans utilisateur (401)
 * - bloque les routes "admin" pour les non-admins (403)
 */
SL.gateway.use('auth', function (req) {
  var token = req.headers.authorization;
  req.user = token ? SL.services.auth.resolveToken(token) : null;

  if (req.route.auth && !req.user) {
    return { status: 401, body: { error: 'Authentification requise' } };
  }
  if (req.route.admin && !SL.services.auth.isAdmin(req.user)) {
    return { status: 403, body: { error: 'Accès réservé aux administrateurs' } };
  }
});
