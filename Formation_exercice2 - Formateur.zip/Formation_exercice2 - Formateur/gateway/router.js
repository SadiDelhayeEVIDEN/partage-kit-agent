/*
 * Routeur : enregistrement des routes "/api/xxx/:param" et matching.
 */
SL.gateway.router = {
  routes: [],

  add: function (method, pattern, service, handler, options) {
    options = options || {};
    var keys = [];
    var regex = new RegExp('^' + pattern.replace(/:(\w+)/g, function (_, k) {
      keys.push(k);
      return '([^/]+)';
    }) + '$');
    this.routes.push({
      method: method,
      pattern: pattern,
      service: service,
      handler: handler,
      keys: keys,
      regex: regex,
      auth: !!options.auth,
      admin: !!options.admin
    });
  },

  match: function (method, path) {
    for (var i = 0; i < this.routes.length; i++) {
      var r = this.routes[i];
      if (r.method !== method) continue;
      var m = path.match(r.regex);
      if (m) {
        var params = {};
        r.keys.forEach(function (k, idx) { params[k] = decodeURIComponent(m[idx + 1]); });
        return { route: r, params: params };
      }
    }
    return null;
  },

  parse: function (url) {
    var parts = url.split('?');
    var query = {};
    if (parts[1]) {
      parts[1].split('&').forEach(function (pair) {
        var kv = pair.split('=');
        if (kv[0]) query[decodeURIComponent(kv[0])] = decodeURIComponent(kv[1] || '');
      });
    }
    return { path: parts[0], query: query };
  }
};
