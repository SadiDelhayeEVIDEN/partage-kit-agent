/*
 * Démarrage de l'application : seed + abonnements aux événements.
 * Doit être chargé APRÈS tous les services et AVANT le frontend.
 */
SL.bootstrap = function () {
  if (!SL.infra.storage.getValue('seeded_v3')) {
    SL.seed.run();
  }
  SL.services.notification.init();
  SL.services.analytics.init();
  SL.logger.info('bootstrap', 'ShopLegacy démarré v' + SL.version);
};

SL.bootstrap();
