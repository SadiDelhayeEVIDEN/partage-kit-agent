/*
 * ShopLegacy - namespace global
 * Tous les modules s'enregistrent sur window.SL (pas de modules ES : on doit
 * pouvoir ouvrir l'application en double-cliquant sur index.html).
 * ATTENTION : l'ordre des <script> dans index.html est IMPORTANT.
 */
var SL = window.SL || {};
window.SL = SL;

SL.version = '1.3.7-legacy';
SL.services = SL.services || {};
SL.controllers = SL.controllers || {};
SL.repositories = SL.repositories || {};
SL.models = SL.models || {};
SL.infra = SL.infra || {};
SL.shared = SL.shared || {};
SL.ui = SL.ui || {};
SL.ui.pages = SL.ui.pages || {};
