/*
 * Configuration globale.
 * TODO (2019) : déplacer dans un fichier d'environnement.
 * TODO (2021) : ne surtout pas committer la clé de paiement... (trop tard)
 */
SL.config = {
  appName: 'ShopLegacy',
  currency: 'EUR',
  storagePrefix: 'shoplegacy_',
  pageSize: 8,
  gateway: {
    latencyMin: 40,
    latencyMax: 180,
    rateLimit: 100,
    rateWindowMs: 60 * 1000 * 1000 // fenêtre de 1 minute
  },
  payment: {
    provider: 'FakeStripe',
    apiKey: 'sk_live_51HxLegacyDoNotCommit_9f8a7b6c5d',
    fraudLimit: 1000
  },
  shipping: {
    freeThreshold: 50,
    baseRate: 4.9,
    perKg: 1.2
  },
  adminEmail: 'admin@shop.fr',
  features: {
    promo: true,
    analytics: true,
    newCheckout: false // jamais activé
  }
};

// utilisé par l'ancien catalogue (et peut-être ailleurs ?)
var PAGE_SIZE = 8;
