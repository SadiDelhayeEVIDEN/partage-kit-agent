/*
 * Logger maison. Garde les 500 dernières entrées en mémoire.
 */
SL.logger = {
  entries: [],
  listeners: [],
  enabled: true,

  log: function (level, source, message, data) {
    if (!this.enabled) return;
    var entry = { at: Date.now(), level: level, source: source, message: message, data: data };
    this.entries.push(entry);
    if (this.entries.length > 500) this.entries.shift();
    for (var i = 0; i < this.listeners.length; i++) {
      try { this.listeners[i](entry); } catch (e) { /* on ignore */ }
    }
    if (level === 'error') console.error('[' + source + ']', message, data || '');
    else if (window.SL_DEBUG) console.log('[' + level + '][' + source + ']', message, data || '');
  },
  debug: function (s, m, d) { this.log('debug', s, m, d); },
  info: function (s, m, d) { this.log('info', s, m, d); },
  warn: function (s, m, d) { this.log('warn', s, m, d); },
  error: function (s, m, d) { this.log('error', s, m, d); },
  onEntry: function (fn) { this.listeners.push(fn); }
};
