/*
 * Manifeste des services et de leurs dépendances.
 * Maintenu "à la main" lors de la refonte de 2020. Utilisé par architecture.html.
 * Dernière mise à jour : 03/2020 (Kevin)
 */
SL.manifest = {
  services: [
    { id: 'frontend', label: 'Frontend', layer: 'ui', deps: ['gateway'] },
    { id: 'gateway', label: 'API Gateway', layer: 'edge', deps: ['user', 'catalog', 'cart', 'order', 'inventory', 'shipping', 'notification', 'analytics'] },
    { id: 'user', label: 'User / Auth', layer: 'domain', deps: [] },
    { id: 'catalog', label: 'Catalog', layer: 'domain', deps: ['inventory'] },
    { id: 'cart', label: 'Cart', layer: 'domain', deps: ['catalog', 'pricing'] },
    { id: 'pricing', label: 'Pricing / Promo', layer: 'domain', deps: [] },
    { id: 'order', label: 'Order', layer: 'domain', deps: ['cart', 'payment', 'inventory'] },
    { id: 'payment', label: 'Payment', layer: 'domain', deps: [] },
    { id: 'inventory', label: 'Inventory', layer: 'domain', deps: [] },
    { id: 'shipping', label: 'Shipping', layer: 'domain', deps: [] },
    { id: 'notification', label: 'Notification', layer: 'support', deps: ['user'] },
    { id: 'analytics', label: 'Analytics', layer: 'support', deps: ['order'] },
    { id: 'legacy-crm', label: 'Legacy CRM', layer: 'support', deps: ['user', 'order'] }
  ]
};
