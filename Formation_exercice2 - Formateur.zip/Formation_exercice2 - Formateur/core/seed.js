/*
 * Données initiales (produits, stock, utilisateurs).
 * Prix stockés HT.
 */
SL.seed = {
  products: [
    { id: 1, name: 'Casque audio Bluetooth', price: 59.99, category: 'electronics', weight: 0.4, image: '🎧' },
    { id: 2, name: 'Clavier mécanique', price: 89.9, category: 'electronics', weight: 1.1, image: '⌨️' },
    { id: 3, name: 'Souris ergonomique', price: 24.99, category: 'electronics', weight: 0.2, image: '🖱️' },
    { id: 4, name: 'Écran 27 pouces', price: 249, category: 'electronics', weight: 5.5, image: '🖥️' },
    { id: 5, name: 'Clean Code', price: 32.5, category: 'books', weight: 0.7, image: '📘' },
    { id: 6, name: 'Refactoring', price: 41.9, category: 'books', weight: 0.9, image: '📗' },
    { id: 7, name: 'Design Patterns', price: 45, category: 'books', weight: 1.0, image: '📙' },
    { id: 8, name: 'Domain-Driven Design', price: 52.3, category: 'books', weight: 1.2, image: '📕' },
    { id: 9, name: 'The Pragmatic Programmer', price: 38.1, category: 'books', weight: 0.6, image: '📓' },
    { id: 10, name: 'T-shirt "It works on my machine"', price: 19.99, category: 'clothing', weight: 0.2, image: '👕' },
    { id: 11, name: 'Sweat à capuche dev', price: 44.9, category: 'clothing', weight: 0.6, image: '🧥' },
    { id: 12, name: 'Chaussettes binaires', price: 9.99, category: 'clothing', weight: 0.1, image: '🧦' },
    { id: 13, name: 'Casquette 404', price: 14.5, category: 'clothing', weight: 0.15, image: '🧢' },
    { id: 14, name: 'Café en grains 1kg', price: 18.3, category: 'food', weight: 1.0, image: '☕' },
    { id: 15, name: 'Thé vert bio', price: 7.1, category: 'food', weight: 0.2, image: '🍵' },
    { id: 16, name: 'Barres énergétiques x12', price: 15.6, category: 'food', weight: 0.6, image: '🍫' },
    { id: 17, name: 'Pizza surgelée (debug night)', price: 6.7, category: 'food', weight: 0.5, image: '🍕' },
    { id: 18, name: 'Lampe de bureau LED', price: 34.9, category: 'home', weight: 1.3, image: '💡' },
    { id: 19, name: 'Plante d\'intérieur', price: 22, category: 'home', weight: 2.0, image: '🪴' },
    { id: 20, name: 'Tasse "Ship it"', price: 11.9, category: 'home', weight: 0.35, image: '☕' },
    { id: 21, name: 'Canard en caoutchouc (debug)', price: 4.99, category: 'home', weight: 0.05, image: '🦆' },
    { id: 22, name: 'Coussin lombaire', price: 27.4, category: 'home', weight: 0.8, image: '🛋️' },
    { id: 23, name: 'Webcam HD', price: 49.9, category: 'electronics', weight: 0.3, image: '📷' },
    { id: 24, name: 'Hub USB-C', price: 29.9, category: 'electronics', weight: 0.15, image: '🔌' }
  ],
  stock: { 1: 12, 2: 5, 3: 30, 4: 2, 5: 15, 6: 8, 7: 4, 8: 6, 9: 10, 10: 50, 11: 20, 12: 100, 13: 25, 14: 40, 15: 60, 16: 18, 17: 9, 18: 7, 19: 3, 20: 35, 21: 200, 22: 11, 23: 14, 24: 22 },
  users: [
    { id: 1, email: 'admin@shop.fr', password: 'admin123', name: 'Admin', role: 'admin' },
    { id: 2, email: 'alice@shop.fr', password: 'alice', name: 'Alice Martin', role: 'customer' },
    { id: 3, email: 'bob@shop.fr', password: 'bob', name: 'Bob Durand', role: 'customer' }
  ],

  run: function () {
    var st = SL.infra.storage;
    st.save('products', this.products.slice());
    var stockRows = [];
    for (var id in this.stock) stockRows.push({ productId: parseInt(id, 10), qty: this.stock[id] });
    st.save('stock', stockRows);
    st.save('users', JSON.parse(JSON.stringify(this.users)));
    st.save('orders', []);
    st.save('carts', []);
    st.save('payments', []);
    st.save('notifications', []);
    st.save('sessions', []);
    st.save('analytics', []);
    st.setValue('seeded_v3', true);
    SL.logger.info('seed', 'Base initialisée');
  }
};
