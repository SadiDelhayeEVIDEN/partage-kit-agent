describe('services/catalog', function () {
  beforeEach(function () { Fixtures.resetDb(); });

  it('renvoie le nombre total de produits', function () {
    expect(SL.services.catalog.list({ page: 1 }).total).toBe(24);
  });

  it('renvoie une page complète de pageSize produits', function () {
    var res = SL.services.catalog.list({ page: 1 });
    expect(res.items).toHaveLength(SL.config.pageSize);
  });

  it('filtre par catégorie', function () {
    var res = SL.services.catalog.list({ category: 'books' });
    expect(res.total).toBe(5);
    res.items.forEach(function (p) { expect(p.category).toBe('books'); });
  });

  it('recherche par nom (insensible à la casse)', function () {
    var res = SL.services.catalog.list({ search: 'CLAVIER' });
    expect(res.total).toBe(1);
  });

  it('lève une 404 pour un produit inconnu', function () {
    expect(function () { SL.services.catalog.get(9999); }).toThrow('introuvable');
  });

  it('enrichit le produit avec son stock', function () {
    expect(SL.services.catalog.get(1).stock).toBe(12);
  });
});
