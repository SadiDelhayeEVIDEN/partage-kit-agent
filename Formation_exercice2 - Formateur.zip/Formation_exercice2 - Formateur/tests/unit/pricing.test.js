describe('services/pricing', function () {
  it('calcule le total TTC d\'un produit high-tech', function () {
    var res = SL.services.pricing.computeCart([Fixtures.line(10, 1, 'electronics')]);
    expect(res.subtotalHT).toBe(10);
    expect(res.totalTTC).toBe(12);
  });

  it('renvoie un total à 0 pour un panier vide', function () {
    var res = SL.services.pricing.computeCart([]);
    expect(res.totalTTC).toBe(0);
  });

  it('renvoie des montants arrondis au centime', function () {
    var res = SL.services.pricing.computeCart([Fixtures.line(19.99, 3, 'electronics')]);
    expect(res.totalTTC).toHaveDecimalsAtMost(2);
    expect(res.tva).toHaveDecimalsAtMost(2);
  });

  // Test écrit en 2019 lors de la migration des constantes
  it('applique la TVA par défaut (20 %) aux livres', function () {
    expect(SL.pricingRules.tvaFor('books')).toBe(0.2);
  });
});

describe('services/promo', function () {
  it('applique un code pourcentage', function () {
    expect(SL.services.promo.applyPromo(100, 'BIENVENUE10')).toBe(90);
  });

  it('applique un code montant fixe', function () {
    expect(SL.services.promo.applyPromo(100, 'LEGACY5')).toBe(95);
  });

  it('ignore un code expiré', function () {
    expect(SL.services.promo.applyPromo(100, 'NOEL25')).toBe(100);
  });

  it('ignore un code inconnu', function () {
    expect(SL.services.promo.applyPromo(100, 'FAUX')).toBe(100);
  });
});
