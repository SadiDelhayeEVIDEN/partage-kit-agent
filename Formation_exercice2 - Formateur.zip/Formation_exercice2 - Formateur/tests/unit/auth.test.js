describe('services/auth', function () {
  beforeEach(function () { Fixtures.resetDb(); });

  it('connecte un utilisateur avec les bons identifiants', function () {
    var res = Fixtures.login('alice@shop.fr', 'alice');
    expect(res.token).toBeTruthy();
    expect(res.user.email).toBe('alice@shop.fr');
  });

  it('refuse un mauvais mot de passe', function () {
    expect(function () { Fixtures.login('alice@shop.fr', 'wrong'); }).toThrow('Identifiants invalides');
  });

  it('retrouve l\'utilisateur à partir du token', function () {
    var res = Fixtures.login();
    expect(SL.services.auth.resolveToken(res.token).id).toBe(2);
  });

  it('reconnaît un administrateur', function () {
    var admin = SL.repositories.user.findByEmail('admin@shop.fr');
    expect(SL.services.auth.isAdmin(admin)).toBe(true);
  });

  xit('TODO : vérifier qu\'un client n\'est pas administrateur', function () {});
});
