describe('shared/money', function () {
  it('arrondit à 2 décimales', function () {
    expect(SL.shared.money.round(0.1 + 0.2)).toBe(0.3);
    expect(SL.shared.money.round(1.005)).toBe(1.01);
  });

  it('additionne sans erreur de flottant', function () {
    expect(SL.shared.money.add(0.1, 0.2)).toBe(0.3);
  });

  it('formate en euros', function () {
    expect(SL.shared.money.format(12.5)).toBe('12,50 €');
  });
});

describe('shared/validators', function () {
  it('valide un email correct', function () {
    expect(SL.shared.validators.email('alice@shop.fr')).toBeTruthy();
  });

  it('rejette un email sans domaine', function () {
    expect(SL.shared.validators.email('alice@')).toBeFalsy();
  });

  it('valide un numéro de carte à 16 chiffres (avec espaces)', function () {
    expect(SL.shared.validators.cardNumber('4242 4242 4242 4242')).toBeTruthy();
  });

  it('rejette un numéro de carte trop court', function () {
    expect(SL.shared.validators.cardNumber('4242')).toBeFalsy();
  });
});
