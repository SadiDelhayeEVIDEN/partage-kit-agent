describe('services/shipping', function () {
  it('facture la livraison sous le seuil de gratuité', function () {
    expect(SL.services.shipping.compute(30, 1)).toBe(6.1);
  });

  it('offre la livraison au-dessus du seuil', function () {
    expect(SL.services.shipping.compute(80, 3)).toBe(0);
  });

  it('offre la livraison à partir de 50 € (seuil inclus)', function () {
    expect(SL.services.shipping.compute(50, 1)).toBe(0);
  });
});
