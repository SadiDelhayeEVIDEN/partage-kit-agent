describe('services/cart', function () {
  beforeEach(function () { Fixtures.resetDb(); });

  it('ajoute un produit au panier', function () {
    var cart = SL.services.cart.addItem('u1', 1, 2);
    expect(cart.items).toHaveLength(1);
    expect(cart.count).toBe(2);
  });

  it('cumule les quantités pour un même produit', function () {
    SL.services.cart.addItem('u1', 3, 1);
    var cart = SL.services.cart.addItem('u1', 3, 2);
    expect(cart.items).toHaveLength(1);
    expect(cart.count).toBe(3);
  });

  it('refuse d\'ajouter plus que le stock disponible', function () {
    expect(function () { SL.services.cart.addItem('u1', 4, 50); }).toThrow('Stock insuffisant');
  });

  it('retire un produit du panier', function () {
    SL.services.cart.addItem('u1', 1, 1);
    var cart = SL.services.cart.removeItem('u1', 1);
    expect(cart.items).toHaveLength(0);
  });

  it('refuse un code promo invalide', function () {
    expect(function () { SL.services.cart.setPromo('u1', 'NOPE'); }).toThrow('invalide');
  });
});
