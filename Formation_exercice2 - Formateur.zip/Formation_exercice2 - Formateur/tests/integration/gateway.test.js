describe('gateway', function () {
  beforeEach(function () { Fixtures.resetDb(); });

  it('renvoie 404 pour une route inconnue', function () {
    return Fixtures.api('GET', '/api/nope').then(function (res) {
      expect(res.status).toBe(404);
    });
  });

  it('renvoie 401 sur une route protégée sans token', function () {
    return Fixtures.api('GET', '/api/orders').then(function (res) {
      expect(res.status).toBe(401);
    });
  });

  it('renvoie la liste paginée des produits', function () {
    return Fixtures.api('GET', '/api/products?page=1').then(function (res) {
      expect(res.status).toBe(200);
      expect(res.body.total).toBe(24);
    });
  });

  it('transmet les paramètres de route au controller', function () {
    return Fixtures.api('GET', '/api/products/7').then(function (res) {
      expect(res.body.name).toBe('Design Patterns');
    });
  });
});
