describe('parcours de commande (intégration)', function () {
  beforeEach(function () { Fixtures.resetDb(); });

  it('crée une commande payée avec une carte valide', function () {
    var session = Fixtures.login();
    SL.services.cart.addItem(session.user.id, 1, 1);
    return Fixtures.api('POST', '/api/orders/checkout', { address: '1 rue du Test', card: Fixtures.validCard }, session.token)
      .then(function (res) {
        expect(res.status).toBe(201);
        expect(res.body.status).toBe('PAID');
        expect(res.body.transactionId).toBeTruthy();
      });
  });

  it('vide le panier après la commande', function () {
    var session = Fixtures.login();
    SL.services.cart.addItem(session.user.id, 1, 1);
    return Fixtures.api('POST', '/api/orders/checkout', { address: '1 rue du Test', card: Fixtures.validCard }, session.token)
      .then(function () {
        expect(SL.services.cart.summary(session.user.id).count).toBe(0);
      });
  });

  it('décrémente le stock après une commande payée', function () {
    var session = Fixtures.login();
    SL.services.cart.addItem(session.user.id, 1, 2);
    return Fixtures.api('POST', '/api/orders/checkout', { address: '1 rue du Test', card: Fixtures.validCard }, session.token)
      .then(function () {
        expect(SL.services.inventory.getStock(1)).toBe(10);
      });
  });

  it('refuse une commande avec un panier vide', function () {
    var session = Fixtures.login();
    return Fixtures.api('POST', '/api/orders/checkout', { address: 'x', card: Fixtures.validCard }, session.token)
      .then(function (res) {
        expect(res.status).toBe(400);
      });
  });

  it('renvoie 402 si le paiement est refusé', function () {
    var session = Fixtures.login();
    SL.services.cart.addItem(session.user.id, 1, 1);
    return Fixtures.api('POST', '/api/orders/checkout', { address: 'x', card: Fixtures.declinedCard }, session.token)
      .then(function (res) {
        expect(res.status).toBe(402);
      });
  });
});
