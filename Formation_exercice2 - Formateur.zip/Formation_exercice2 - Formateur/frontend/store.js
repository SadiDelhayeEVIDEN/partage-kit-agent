/*
 * Store global de l'interface (état partagé + abonnements).
 */
SL.ui.store = {
  state: {
    token: SL.infra.storage.getValue('token', null),
    user: null,
    cartCount: 0,
    route: ''
  },
  listeners: [],

  set: function (patch) {
    Object.assign(this.state, patch);
    if ('token' in patch) {
      if (patch.token) SL.infra.storage.setValue('token', patch.token);
      else SL.infra.storage.removeValue('token');
    }
    this.listeners.forEach(function (fn) { fn(SL.ui.store.state); });
  },

  subscribe: function (fn) {
    this.listeners.push(fn);
  }
};
