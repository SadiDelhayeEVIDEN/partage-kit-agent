/*
 * Application : routeur par hash + initialisation.
 */
SL.app = {
  routes: {
    catalog: SL.ui.pages.catalog,
    cart: SL.ui.pages.cart,
    checkout: SL.ui.pages.checkout,
    orders: SL.ui.pages.orders,
    notifications: SL.ui.pages.notifications,
    login: SL.ui.pages.login,
    admin: SL.ui.pages.admin
  },

  navigate: function () {
    var name = (location.hash || '#/catalog').replace('#/', '').split('?')[0] || 'catalog';
    var page = this.routes[name] || this.routes.catalog;
    SL.ui.store.set({ route: name });
    page.render(document.getElementById('app'));
  },

  refreshCartCount: function () {
    SL.api.get('/api/cart').then(function (cart) {
      SL.ui.store.set({ cartCount: cart.count });
    }).catch(function () {});
  },

  start: function () {
    var self = this;
    // on s'assure que les notifications sont bien branchées
    SL.services.notification.init();

    SL.ui.store.subscribe(SL.ui.renderHeader);
    window.addEventListener('hashchange', function () { self.navigate(); });

    var ready = SL.ui.store.state.token
      ? SL.api.get('/api/auth/me').then(function (user) {
        SL.ui.store.set({ user: user });
      }).catch(function () {
        SL.ui.store.set({ token: null, user: null });
      })
      : Promise.resolve();

    ready.then(function () {
      SL.ui.renderHeader();
      self.refreshCartCount();
      self.navigate();
    });
  }
};

document.addEventListener('DOMContentLoaded', function () {
  SL.app.start();
});
