/*
 * Client API du frontend : passe par le simulateur HTTP -> API Gateway.
 */
SL.api = {
  call: function (method, url, body) {
    var headers = { 'x-caller': 'frontend' };
    if (SL.ui.store.state.token) headers.authorization = SL.ui.store.state.token;
    return SL.infra.http.request(method, url, body, headers).then(function (res) {
      if (res.status >= 400) {
        var err = new Error((res.body && res.body.error) || 'Erreur ' + res.status);
        err.status = res.status;
        throw err;
      }
      return res.body;
    });
  },
  get: function (url) { return this.call('GET', url); },
  post: function (url, body) { return this.call('POST', url, body || {}); },
  put: function (url, body) { return this.call('PUT', url, body || {}); },
  del: function (url) { return this.call('DELETE', url); }
};
