SL.ui.pages.catalog = {
  state: { page: 1, category: '', search: '' },

  render: function (root) {
    var self = this;
    root.innerHTML =
      '<h1>Catalogue</h1>' +
      '<div class="toolbar">' +
      '<select id="cat-filter"><option value="">Toutes les catégories</option></select>' +
      '<input id="search" placeholder="Rechercher un produit..." value="' + SL.helpers.escapeHtml(self.state.search) + '">' +
      '<span class="muted" id="result-count"></span>' +
      '</div>' +
      '<div id="products">' + SL.ui.loader() + '</div>';

    SL.api.get('/api/categories').then(function (cats) {
      var sel = document.getElementById('cat-filter');
      cats.forEach(function (c) {
        var o = document.createElement('option');
        o.value = c.id;
        o.textContent = c.label;
        if (c.id === self.state.category) o.selected = true;
        sel.appendChild(o);
      });
      sel.onchange = function () {
        self.state.category = sel.value;
        self.state.page = 1;
        self.load();
      };
    });

    document.getElementById('search').oninput = SL.helpers.debounce(function (e) {
      self.state.search = e.target.value;
      self.state.page = 1;
      self.load();
    }, 300);

    this.load();
  },

  load: function () {
    var self = this;
    var q = '?page=' + this.state.page +
      (this.state.category ? '&category=' + this.state.category : '') +
      (this.state.search ? '&search=' + encodeURIComponent(this.state.search) : '');

    SL.api.get('/api/products' + q).then(function (res) {
      var container = document.getElementById('products');
      if (!container) return;
      document.getElementById('result-count').textContent = res.total + ' produit(s)';
      if (!res.items.length) {
        container.innerHTML = '<div class="empty">Aucun produit.</div>';
        return;
      }
      container.innerHTML =
        '<div class="grid">' + res.items.map(SL.ui.productCard).join('') + '</div>' +
        SL.ui.pagination(res.page, res.totalPages);

      SL.helpers.qsa('.add-to-cart', container).forEach(function (btn) {
        btn.onclick = function () {
          btn.disabled = true;
          SL.api.post('/api/cart/items', { productId: btn.dataset.id, qty: 1 })
            .then(function (cart) {
              SL.ui.store.set({ cartCount: cart.count });
              SL.ui.toast('Produit ajouté au panier', 'success');
            })
            .catch(function (e) { SL.ui.toast(e.message, 'error'); })
            .then(function () { btn.disabled = false; });
        };
      });
      SL.helpers.qsa('.page-btn', container).forEach(function (btn) {
        btn.onclick = function () {
          self.state.page = parseInt(btn.dataset.page, 10);
          self.load();
          window.scrollTo(0, 0);
        };
      });
    }).catch(function (e) {
      SL.ui.toast(e.message, 'error');
    });
  }
};
