SL.ui.pages.cart = {
  render: function (root) {
    root.innerHTML = '<h1>Mon panier</h1>' + SL.ui.loader();
    this.load(root);
  },

  load: function (root) {
    var self = this;
    SL.api.get('/api/cart').then(function (cart) {
      SL.ui.store.set({ cartCount: cart.count });
      // calcul des frais de port côté front (même règle que le service shipping)
      var shipping = cart.totalTTC >= SL.config.shipping.freeThreshold
        ? 0
        : SL.config.shipping.baseRate + SL.config.shipping.perKg * cart.weight;

      root.innerHTML =
        '<h1>Mon panier</h1>' +
        '<div class="two-cols">' +
        '<div class="card">' + SL.ui.cartLines(cart) + '</div>' +
        '<div class="card">' +
        '<h2>Récapitulatif</h2>' +
        SL.ui.cartTotals(cart, cart.items.length ? shipping : undefined) +
        '<div class="toolbar" style="margin-top:16px">' +
        '<input id="promo-code" placeholder="Code promo" value="' + (cart.promoCode || '') + '">' +
        '<button class="btn secondary" id="apply-promo">Appliquer</button>' +
        '</div>' +
        '<p class="muted" style="font-size:0.8rem">Essayez BIENVENUE10 ou LEGACY5. Livraison offerte dès ' + SL.config.shipping.freeThreshold + ' €.</p>' +
        '<button class="btn" id="go-checkout"' + (cart.items.length ? '' : ' disabled') + '>Passer commande</button>' +
        '</div></div>';

      SL.helpers.qsa('.remove-item', root).forEach(function (btn) {
        btn.onclick = function () {
          SL.api.del('/api/cart/items/' + btn.dataset.id).then(function () {
            SL.ui.toast('Article retiré');
            self.load(root);
          }).catch(function (e) { SL.ui.toast(e.message, 'error'); });
        };
      });

      document.getElementById('apply-promo').onclick = function () {
        var code = document.getElementById('promo-code').value;
        SL.api.post('/api/cart/promo', { code: code }).then(function () {
          SL.ui.toast('Code appliqué', 'success');
          self.load(root);
        }).catch(function (e) { SL.ui.toast(e.message, 'error'); });
      };

      document.getElementById('go-checkout').onclick = function () {
        location.hash = '#/checkout';
      };
    });
  }
};
