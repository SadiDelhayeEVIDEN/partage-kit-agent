SL.ui.pages.notifications = {
  render: function (root) {
    if (!SL.ui.store.state.user) {
      root.innerHTML = '<div class="notice">Connectez-vous pour voir vos emails. <a href="#/login">Se connecter</a></div>';
      return;
    }
    root.innerHTML = '<h1>Boîte mail (simulée)</h1>' + SL.ui.loader();
    SL.api.get('/api/notifications').then(function (list) {
      var html = list.length
        ? list.map(function (n) {
          return '<div class="mail"><div class="subject">' + SL.helpers.escapeHtml(n.subject) + '</div>' +
            '<div class="muted">' + SL.helpers.formatDate(n.at) + ' — à ' + n.to + '</div>' +
            '<div>' + SL.helpers.escapeHtml(n.body) + '</div></div>';
        }).join('')
        : '<div class="empty">Aucun email.</div>';
      root.innerHTML = '<h1>Boîte mail (simulée)</h1><div class="card">' + html + '</div>';
    });
  }
};
