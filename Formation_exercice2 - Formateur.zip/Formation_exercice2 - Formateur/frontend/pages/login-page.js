SL.ui.pages.login = {
  render: function (root) {
    root.innerHTML =
      '<h1>Connexion</h1>' +
      '<div class="notice">Comptes de démo : <b>alice@shop.fr / alice</b> (client) — <b>admin@shop.fr / admin123</b> (admin)</div>' +
      '<div class="two-cols">' +
      '<div class="card"><h2>Se connecter</h2><form class="form" id="login-form">' +
      '<input id="login-email" placeholder="Email" value="alice@shop.fr">' +
      '<input id="login-password" type="password" placeholder="Mot de passe" value="alice">' +
      '<button class="btn" type="submit">Connexion</button></form></div>' +
      '<div class="card"><h2>Créer un compte</h2><form class="form" id="register-form">' +
      '<input id="reg-name" placeholder="Nom">' +
      '<input id="reg-email" placeholder="Email">' +
      '<input id="reg-password" type="password" placeholder="Mot de passe">' +
      '<button class="btn secondary" type="submit">Inscription</button></form></div>' +
      '</div>';

    function onLogged(res) {
      SL.ui.store.set({ token: res.token, user: res.user });
      SL.ui.toast('Bienvenue ' + res.user.name, 'success');
      SL.app.refreshCartCount();
      location.hash = '#/catalog';
    }

    document.getElementById('login-form').onsubmit = function (e) {
      e.preventDefault();
      SL.api.post('/api/auth/login', {
        email: document.getElementById('login-email').value,
        password: document.getElementById('login-password').value
      }).then(onLogged).catch(function (err) { SL.ui.toast(err.message, 'error'); });
    };

    document.getElementById('register-form').onsubmit = function (e) {
      e.preventDefault();
      SL.api.post('/api/auth/register', {
        name: document.getElementById('reg-name').value,
        email: document.getElementById('reg-email').value,
        password: document.getElementById('reg-password').value
      }).then(onLogged).catch(function (err) { SL.ui.toast(err.message, 'error'); });
    };
  }
};
