SL.ui.pages.orders = {
  render: function (root) {
    if (!SL.ui.store.state.user) {
      root.innerHTML = '<div class="notice">Connectez-vous pour voir vos commandes. <a href="#/login">Se connecter</a></div>';
      return;
    }
    root.innerHTML = '<h1>Mes commandes</h1>' + SL.ui.loader();
    SL.api.get('/api/orders').then(function (orders) {
      if (!orders.length) {
        root.innerHTML = '<h1>Mes commandes</h1><div class="empty">Aucune commande pour le moment.</div>';
        return;
      }
      var rows = orders.map(function (o) {
        return '<tr>' +
          '<td>#' + o.id + '</td>' +
          '<td>' + SL.helpers.formatDate(o.createdAt) + '</td>' +
          '<td>' + o.items.map(function (i) { return i.qty + '× ' + SL.helpers.escapeHtml(i.name); }).join('<br>') + '</td>' +
          '<td>' + (o.promoCode || '-') + '</td>' +
          '<td>' + o.total + ' €</td>' +
          '<td>' + SL.ui.statusBadge(o.status) + (o.failureReason ? '<br><small class="danger">' + o.failureReason + '</small>' : '') + '</td>' +
          '</tr>';
      }).join('');
      root.innerHTML = '<h1>Mes commandes</h1><div class="card"><table>' +
        '<thead><tr><th>N°</th><th>Date</th><th>Articles</th><th>Promo</th><th>Total</th><th>Statut</th></tr></thead>' +
        '<tbody>' + rows + '</tbody></table></div>';
    }).catch(function (e) { SL.ui.toast(e.message, 'error'); });
  }
};
