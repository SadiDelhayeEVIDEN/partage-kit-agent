SL.ui.pages.checkout = {
  render: function (root) {
    if (!SL.ui.store.state.user) {
      root.innerHTML = '<div class="notice">Vous devez être connecté pour commander. <a href="#/login">Se connecter</a></div>';
      return;
    }
    root.innerHTML = '<h1>Paiement</h1>' + SL.ui.loader();

    SL.api.get('/api/cart').then(function (cart) {
      if (!cart.items.length) {
        root.innerHTML = '<h1>Paiement</h1><div class="empty">Panier vide. <a href="#/catalog">Retour au catalogue</a></div>';
        return;
      }
      root.innerHTML =
        '<h1>Paiement</h1>' +
        '<div class="two-cols">' +
        '<div class="card"><form class="form" id="checkout-form">' +
        '<label>Adresse de livraison</label>' +
        '<textarea id="address" rows="3">12 rue du Legacy, 75000 Paris</textarea>' +
        '<label>Numéro de carte</label>' +
        '<input id="card" value="4242 4242 4242 4242">' +
        '<p class="muted" style="font-size:0.8rem">Cartes de test : 4242 4242 4242 4242 (OK) — 4000 0000 0000 0000 (refusée). Paiement refusé au-delà de ' + SL.config.payment.fraudLimit + ' €.</p>' +
        '<button class="btn" type="submit" id="pay-btn">Payer</button>' +
        '</form></div>' +
        '<div class="card"><h2>Votre commande</h2>' + SL.ui.cartTotals(cart) + '</div>' +
        '</div>';

      document.getElementById('checkout-form').onsubmit = function (e) {
        e.preventDefault();
        var btn = document.getElementById('pay-btn');
        btn.disabled = true;
        btn.textContent = 'Paiement en cours...';
        SL.api.post('/api/orders/checkout', {
          address: document.getElementById('address').value,
          card: { number: document.getElementById('card').value }
        }).then(function (order) {
          SL.ui.toast('Commande #' + order.id + ' confirmée !', 'success');
          SL.app.refreshCartCount();
          location.hash = '#/orders';
        }).catch(function (err) {
          SL.ui.toast(err.message, 'error');
          SL.app.refreshCartCount();
          btn.disabled = false;
          btn.textContent = 'Payer';
        });
      };
    });
  }
};
