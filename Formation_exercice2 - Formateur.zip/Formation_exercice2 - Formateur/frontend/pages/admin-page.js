SL.ui.pages.admin = {
  render: function (root) {
    var user = SL.ui.store.state.user;
    if (!user || !SL.services.auth.isAdmin(user)) {
      root.innerHTML = '<div class="notice">Accès réservé aux administrateurs.</div>';
      return;
    }
    root.innerHTML = '<h1>Back-office</h1>' + SL.ui.loader();
    this.load(root);
  },

  load: function (root) {
    var self = this;
    Promise.all([
      SL.api.get('/api/admin/dashboard'),
      SL.api.get('/api/admin/inventory'),
      SL.api.get('/api/admin/orders'),
      SL.api.get('/api/admin/payments')
    ]).then(function (r) {
      var d = r[0], inventory = r[1], orders = r[2], payments = r[3];

      var stats = [
        ['Chiffre d\'affaires', SL.helpers.formatPrice(d.revenue)],
        ['Commandes', d.ordersCount],
        ['Payées', d.paidCount],
        ['Échouées', d.failedCount],
        ['Panier moyen', SL.helpers.formatPrice(d.averageBasket)],
        ['Produits en stock bas', d.lowStockCount],
        ['Utilisateurs', d.usersCount]
      ].map(function (s) {
        return '<div class="card stat"><div class="value">' + s[1] + '</div><div class="label">' + s[0] + '</div></div>';
      }).join('');

      var invRows = inventory.map(function (i) {
        return '<tr><td>' + i.image + ' ' + SL.helpers.escapeHtml(i.name) + '</td>' +
          '<td>' + i.qty + (i.low ? ' <span class="badge low">bas</span>' : '') + '</td>' +
          '<td>' + i.available + '</td>' +
          '<td><input type="number" min="0" style="width:80px" value="' + i.qty + '" data-id="' + i.productId + '" class="stock-input"> ' +
          '<button class="btn small save-stock" data-id="' + i.productId + '">OK</button></td></tr>';
      }).join('');

      var orderRows = orders.map(function (o) {
        return '<tr><td>#' + o.id + '</td><td>' + o.userId + '</td><td>' + o.total + ' €</td><td>' + SL.ui.statusBadge(o.status) + '</td>' +
          '<td>' + (o.status === 'PAID' ? '<button class="btn small ship-btn" data-id="' + o.id + '">Expédier</button>' : '') + '</td></tr>';
      }).join('');

      var payRows = payments.slice().reverse().map(function (p) {
        return '<tr><td>' + p.id + '</td><td>#' + p.orderId + '</td><td>' + p.amount + '</td><td>' + (p.ok ? '✅' : '❌ ' + p.reason) + '</td><td class="mono">' + p.card + '</td></tr>';
      }).join('');

      var top = d.topProducts.map(function (t) { return '<li>' + SL.helpers.escapeHtml(t.name) + ' (' + t.qty + ')</li>'; }).join('');

      root.innerHTML =
        '<h1>Back-office</h1>' +
        '<div class="stats">' + stats + '</div>' +
        '<div class="two-cols">' +
        '<div class="card"><h2>Stock</h2><table><thead><tr><th>Produit</th><th>Stock</th><th>Dispo</th><th>Modifier</th></tr></thead><tbody>' + invRows + '</tbody></table></div>' +
        '<div><div class="card"><h2>Top produits ajoutés</h2><ol>' + (top || '<li class="muted">—</li>') + '</ol></div></div>' +
        '</div>' +
        '<div class="card" style="margin-top:20px"><h2>Commandes</h2><table><thead><tr><th>N°</th><th>Client</th><th>Total</th><th>Statut</th><th></th></tr></thead><tbody>' + (orderRows || '<tr><td colspan="5" class="muted">Aucune</td></tr>') + '</tbody></table></div>' +
        '<div class="card" style="margin-top:20px"><h2>Paiements</h2><table><thead><tr><th>Id</th><th>Commande</th><th>Montant</th><th>Résultat</th><th>Carte</th></tr></thead><tbody>' + (payRows || '<tr><td colspan="5" class="muted">Aucun</td></tr>') + '</tbody></table></div>';

      SL.helpers.qsa('.save-stock', root).forEach(function (btn) {
        btn.onclick = function () {
          var input = root.querySelector('.stock-input[data-id="' + btn.dataset.id + '"]');
          SL.api.put('/api/admin/inventory/' + btn.dataset.id, { qty: input.value })
            .then(function () { SL.ui.toast('Stock mis à jour', 'success'); self.load(root); })
            .catch(function (e) { SL.ui.toast(e.message, 'error'); });
        };
      });
      SL.helpers.qsa('.ship-btn', root).forEach(function (btn) {
        btn.onclick = function () {
          SL.api.put('/api/admin/orders/' + btn.dataset.id + '/status', { status: 'SHIPPED' })
            .then(function () { SL.ui.toast('Commande expédiée', 'success'); self.load(root); })
            .catch(function (e) { SL.ui.toast(e.message, 'error'); });
        };
      });
    }).catch(function (e) {
      root.innerHTML = '<div class="notice">' + e.message + '</div>';
    });
  }
};
