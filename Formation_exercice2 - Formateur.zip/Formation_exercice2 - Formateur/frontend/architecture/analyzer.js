/*
 * Analyse du graphe de dépendances : agrégation des sources + détection de cycles.
 */
SL.arch = SL.arch || {};

SL.arch.analyzer = {
  declaredEdges: function () {
    var edges = [];
    SL.manifest.services.forEach(function (s) {
      s.deps.forEach(function (d) { edges.push({ from: s.id, to: d }); });
    });
    return edges;
  },

  httpEdges: function () {
    var map = {};
    SL.infra.storage.get('http_log').forEach(function (e) {
      var k = e.from + '>' + e.to;
      map[k] = map[k] || { from: e.from, to: e.to, count: 0, errors: 0 };
      map[k].count++;
      if (e.status >= 400) map[k].errors++;
    });
    return Object.keys(map).map(function (k) { return map[k]; });
  },

  eventEdges: function () {
    var map = {};
    SL.infra.storage.get('event_log').forEach(function (e) {
      e.listeners.forEach(function (l) {
        var k = e.source + '>' + l + '>' + e.event;
        map[k] = map[k] || { from: e.source, to: l, event: e.event, count: 0 };
        map[k].count++;
      });
    });
    return Object.keys(map).map(function (k) { return map[k]; });
  },

  // Renvoie l'ensemble des arêtes "a>b" qui participent à un cycle
  findCycles: function (edges) {
    var adj = {};
    edges.forEach(function (e) { (adj[e.from] = adj[e.from] || []).push(e.to); });
    var inCycle = {};
    var cycles = [];

    function dfs(node, path) {
      var idx = path.indexOf(node);
      if (idx >= 0) {
        var cycle = path.slice(idx).concat(node);
        cycles.push(cycle);
        for (var i = 0; i < cycle.length - 1; i++) inCycle[cycle[i] + '>' + cycle[i + 1]] = true;
        return;
      }
      if (path.length > 20) return;
      (adj[node] || []).forEach(function (n) { dfs(n, path.concat(node)); });
    }
    Object.keys(adj).forEach(function (n) { dfs(n, []); });
    return { edges: inCycle, cycles: cycles };
  },

  // Incohérences entre le manifeste et ce qui est observé à l'exécution
  warnings: function () {
    var declared = {};
    this.declaredEdges().forEach(function (e) { declared[e.from + '>' + e.to] = true; });
    var ids = SL.manifest.services.map(function (s) { return s.id; });
    var out = [];
    this.httpEdges().forEach(function (e) {
      if (e.from !== 'frontend' && !declared[e.from + '>' + e.to]) {
        out.push('Appel HTTP non déclaré : ' + e.from + ' → ' + e.to);
      }
    });
    this.eventEdges().forEach(function (e) {
      if (ids.indexOf(e.to) < 0) out.push('Abonné inconnu du manifeste : ' + e.to);
    });
    SL.manifest.services.forEach(function (s) {
      if (s.id !== 'frontend' && s.id !== 'gateway' && !SL.services[s.id] && !SL.services[s.id === 'user' ? 'auth' : s.id]) {
        out.push('Service déclaré mais introuvable à l\'exécution : ' + s.id);
      }
    });
    return out;
  }
};
