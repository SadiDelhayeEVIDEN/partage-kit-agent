/*
 * Scénarios de démonstration : génèrent du trafic pour peupler le graphe.
 */
SL.arch.scenarios = {
  _call: function (token, method, url, body) {
    var headers = { 'x-caller': 'frontend' };
    if (token) headers.authorization = token;
    return SL.infra.http.request(method, url, body, headers).then(function (res) { return res.body; });
  },

  checkout: function (cardNumber) {
    var self = this;
    var token;
    return self._call(null, 'POST', '/api/auth/login', { email: 'bob@shop.fr', password: 'bob' })
      .then(function (r) { token = r.token; return self._call(token, 'GET', '/api/products?page=1'); })
      .then(function () { return self._call(token, 'POST', '/api/cart/items', { productId: 5, qty: 1 }); })
      .then(function () { return self._call(token, 'POST', '/api/cart/items', { productId: 12, qty: 2 }); })
      .then(function () { return self._call(token, 'POST', '/api/orders/checkout', { address: '1 rue du Test', card: { number: cardNumber } }); })
      .then(function () { return self._call(token, 'GET', '/api/notifications'); });
  }
};
