/*
 * Rendu SVG du graphe des services.
 */
SL.arch.graph = {
  width: 1000,
  height: 620,
  layers: { ui: 50, edge: 160, domain: 300, support: 560 },
  options: { declared: true, http: true, events: true },
  selected: null,
  onSelect: null,

  positions: function () {
    var self = this;
    var byLayer = {};
    SL.manifest.services.forEach(function (s) { (byLayer[s.layer] = byLayer[s.layer] || []).push(s); });
    var pos = {};
    Object.keys(byLayer).forEach(function (layer) {
      var list = byLayer[layer];
      var step = self.width / (list.length + 1);
      list.forEach(function (s, i) {
        // quinconce pour les couches chargées, sinon les nœuds se chevauchent
        var offset = list.length > 5 && i % 2 ? 70 : 0;
        pos[s.id] = { x: step * (i + 1), y: self.layers[layer] + offset, layer: layer, label: s.label };
      });
    });
    return pos;
  },

  path: function (a, b, bend) {
    var mx = (a.x + b.x) / 2;
    var my = (a.y + b.y) / 2;
    var dx = b.x - a.x, dy = b.y - a.y;
    var len = Math.sqrt(dx * dx + dy * dy) || 1;
    var cx = mx - (dy / len) * bend;
    var cy = my + (dx / len) * bend;
    // on raccourcit l'arrivée pour ne pas cacher la flèche sous le nœud
    var ex = b.x - (dx / len) * 34, ey = b.y - (dy / len) * 22;
    return { d: 'M' + a.x + ',' + a.y + ' Q' + cx + ',' + cy + ' ' + ex + ',' + ey, cx: cx, cy: cy };
  },

  render: function (svg) {
    var self = this;
    var pos = this.positions();
    var an = SL.arch.analyzer;
    var declared = an.declaredEdges();
    var cyc = an.findCycles(declared);
    var parts = [];

    parts.push(
      '<defs>' +
      ['gray:#9ca3af', 'red:#dc2626', 'blue:#2563eb', 'green:#16a34a'].map(function (c) {
        var p = c.split(':');
        return '<marker id="arrow-' + p[0] + '" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0,0 L10,5 L0,10 z" fill="' + p[1] + '"/></marker>';
      }).join('') +
      '</defs>'
    );

    Object.keys(this.layers).forEach(function (l) {
      parts.push('<text class="layer-label" x="8" y="' + (self.layers[l] - 30) + '">' + l + '</text>');
    });

    function ensureNode(id) {
      if (!pos[id]) pos[id] = { x: self.width - 60, y: 30, layer: 'ghost', label: id + ' ?' };
      return pos[id];
    }

    if (this.options.declared) {
      declared.forEach(function (e) {
        var a = ensureNode(e.from), b = ensureNode(e.to);
        var isCycle = cyc.edges[e.from + '>' + e.to];
        var p = self.path(a, b, 0);
        parts.push('<path class="edge-declared' + (isCycle ? ' cycle' : '') + '" d="' + p.d + '" marker-end="url(#arrow-' + (isCycle ? 'red' : 'gray') + ')"/>');
      });
    }

    if (this.options.http) {
      an.httpEdges().forEach(function (e) {
        var a = ensureNode(e.from), b = ensureNode(e.to);
        var p = self.path(a, b, 40);
        parts.push('<path class="edge-http" d="' + p.d + '" marker-end="url(#arrow-blue)"/>');
        parts.push('<text class="edge-label" x="' + p.cx + '" y="' + p.cy + '">' + e.count + (e.errors ? ' (' + e.errors + ' err)' : '') + '</text>');
      });
    }

    if (this.options.events) {
      an.eventEdges().forEach(function (e) {
        var a = ensureNode(e.from), b = ensureNode(e.to);
        var p = self.path(a, b, -50);
        parts.push('<path class="edge-event" d="' + p.d + '" marker-end="url(#arrow-green)"><title>' + e.event + ' ×' + e.count + '</title></path>');
      });
    }

    Object.keys(pos).forEach(function (id) {
      var n = pos[id];
      var w = Math.max(90, n.label.length * 8 + 20);
      parts.push(
        '<g class="node ' + n.layer + (self.selected === id ? ' selected' : '') + '" data-id="' + id + '">' +
        '<rect x="' + (n.x - w / 2) + '" y="' + (n.y - 20) + '" width="' + w + '" height="40"></rect>' +
        '<text x="' + n.x + '" y="' + (n.y + 5) + '" text-anchor="middle">' + n.label + '</text></g>'
      );
    });

    svg.setAttribute('viewBox', '0 0 ' + this.width + ' ' + this.height);
    svg.innerHTML = parts.join('');

    Array.prototype.forEach.call(svg.querySelectorAll('.node'), function (g) {
      g.addEventListener('click', function () {
        self.selected = g.getAttribute('data-id');
        self.render(svg);
        if (self.onSelect) self.onSelect(self.selected);
      });
    });

    return cyc;
  }
};
