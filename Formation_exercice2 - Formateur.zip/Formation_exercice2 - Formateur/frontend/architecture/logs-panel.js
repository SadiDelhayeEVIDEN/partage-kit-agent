/*
 * Tableaux des journaux (appels HTTP, événements, logs applicatifs).
 */
SL.arch.logs = {
  renderHttp: function (el) {
    var rows = SL.infra.storage.get('http_log').slice().reverse().map(function (e) {
      return '<tr><td>' + new Date(e.at).toLocaleTimeString('fr-FR') + '</td><td>' + e.from + '</td><td>' + e.to + '</td>' +
        '<td class="mono">' + e.method + ' ' + SL.helpers.escapeHtml(e.url) + '</td>' +
        '<td class="status-' + String(e.status)[0] + '">' + e.status + '</td><td>' + e.ms + ' ms</td></tr>';
    }).join('');
    el.innerHTML = '<table><thead><tr><th>Heure</th><th>De</th><th>Vers</th><th>Requête</th><th>Statut</th><th>Durée</th></tr></thead><tbody>' +
      (rows || '<tr><td colspan="6" class="muted">Aucun appel enregistré. Utilisez la boutique ou lancez un scénario.</td></tr>') + '</tbody></table>';
  },

  renderEvents: function (el) {
    var rows = SL.infra.storage.get('event_log').slice().reverse().map(function (e) {
      return '<tr><td>' + new Date(e.at).toLocaleTimeString('fr-FR') + '</td><td class="mono">' + e.event + '</td><td>' + e.source + '</td>' +
        '<td>' + (e.listeners.join(', ') || '<span class="muted">aucun</span>') + '</td></tr>';
    }).join('');
    el.innerHTML = '<table><thead><tr><th>Heure</th><th>Événement</th><th>Émetteur</th><th>Abonnés</th></tr></thead><tbody>' +
      (rows || '<tr><td colspan="4" class="muted">Aucun événement.</td></tr>') + '</tbody></table>';
  },

  renderAppLogs: function (el) {
    var rows = SL.logger.entries.slice().reverse().slice(0, 100).map(function (e) {
      return '<tr><td>' + new Date(e.at).toLocaleTimeString('fr-FR') + '</td><td>' + e.level + '</td><td>' + e.source + '</td><td>' + SL.helpers.escapeHtml(e.message) + '</td></tr>';
    }).join('');
    el.innerHTML = '<table><thead><tr><th>Heure</th><th>Niveau</th><th>Source</th><th>Message</th></tr></thead><tbody>' +
      (rows || '<tr><td colspan="4" class="muted">—</td></tr>') + '</tbody></table>';
  }
};
