/*
 * Page architecture : assemble graphe, panneaux latéraux et journaux.
 */
SL.arch.page = {
  refresh: function () {
    var cyc = SL.arch.graph.render(document.getElementById('arch-graph'));
    SL.arch.logs.renderHttp(document.getElementById('http-log'));
    SL.arch.logs.renderEvents(document.getElementById('event-log'));
    SL.arch.logs.renderAppLogs(document.getElementById('app-log'));

    var cycles = cyc.cycles.map(function (c) { return c.join(' → '); });
    var unique = cycles.filter(function (c, i) { return cycles.indexOf(c) === i; });
    var warnings = SL.arch.analyzer.warnings();
    document.getElementById('warnings').innerHTML =
      (unique.length ? unique.map(function (c) { return '<li class="danger">Cycle déclaré : ' + c + '</li>'; }).join('') : '') +
      warnings.map(function (w) { return '<li>' + w + '</li>'; }).join('') ||
      '<li class="muted">Rien à signaler… vraiment ? Le manifeste est-il à jour ?</li>';

    var files = document.querySelectorAll('script[src]').length;
    document.getElementById('stats').innerHTML =
      '<div>Services déclarés : <b>' + SL.manifest.services.length + '</b></div>' +
      '<div>Routes API : <b>' + SL.gateway.router.routes.length + '</b></div>' +
      '<div>Scripts chargés : <b>' + files + '</b></div>' +
      '<div>Middlewares : <b>' + SL.gateway.middlewares.map(function (m) { return m.name; }).join(', ') + '</b></div>';
  },

  showDetails: function (id) {
    var s = SL.manifest.services.find(function (x) { return x.id === id; });
    var http = SL.arch.analyzer.httpEdges();
    var events = SL.arch.analyzer.eventEdges();
    var routes = SL.gateway.router.routes.filter(function (r) { return r.service === id; });
    document.getElementById('details').innerHTML =
      '<h2>' + (s ? s.label : id) + '</h2>' +
      '<div><b>Dépendances déclarées :</b> ' + (s && s.deps.length ? s.deps.join(', ') : '—') + '</div>' +
      '<div><b>Appels HTTP sortants :</b> ' + (http.filter(function (e) { return e.from === id; }).map(function (e) { return e.to + ' (' + e.count + ')'; }).join(', ') || '—') + '</div>' +
      '<div><b>Appels HTTP entrants :</b> ' + (http.filter(function (e) { return e.to === id; }).map(function (e) { return e.from + ' (' + e.count + ')'; }).join(', ') || '—') + '</div>' +
      '<div><b>Événements émis :</b> ' + (events.filter(function (e) { return e.from === id; }).map(function (e) { return e.event; }).filter(function (v, i, a) { return a.indexOf(v) === i; }).join(', ') || '—') + '</div>' +
      '<div><b>Événements écoutés :</b> ' + (events.filter(function (e) { return e.to === id; }).map(function (e) { return e.event; }).filter(function (v, i, a) { return a.indexOf(v) === i; }).join(', ') || '—') + '</div>' +
      '<div><b>Routes exposées :</b><br>' + (routes.map(function (r) { return '<span class="mono">' + r.method + ' ' + r.pattern + '</span>'; }).join('<br>') || '—') + '</div>' +
      '<p class="muted" style="font-size:0.8rem">⚠️ Les appels directs entre services (SL.services.x.y()) ne passent pas par la gateway et sont invisibles ici.</p>';
  },

  start: function () {
    var self = this;
    SL.arch.graph.onSelect = function (id) { self.showDetails(id); };

    ['declared', 'http', 'events'].forEach(function (k) {
      document.getElementById('toggle-' + k).onchange = function (e) {
        SL.arch.graph.options[k] = e.target.checked;
        self.refresh();
      };
    });

    document.getElementById('run-ok').onclick = function () {
      SL.arch.scenarios.checkout('4242 4242 4242 4242').then(function () { self.refresh(); });
    };
    document.getElementById('run-ko').onclick = function () {
      SL.arch.scenarios.checkout('4000 0000 0000 0000').then(function () { self.refresh(); });
    };
    document.getElementById('clear-logs').onclick = function () {
      SL.infra.storage.save('http_log', []);
      SL.infra.storage.save('event_log', []);
      self.refresh();
    };
    document.getElementById('reset-db').onclick = function () {
      if (!confirm('Réinitialiser toutes les données (commandes, stock, comptes) ?')) return;
      SL.infra.storage.clear();
      SL.seed.run();
      self.refresh();
    };

    window.addEventListener('storage', function () { self.refresh(); });
    this.refresh();
  }
};

document.addEventListener('DOMContentLoaded', function () {
  SL.arch.page.start();
});
