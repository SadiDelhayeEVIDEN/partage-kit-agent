SL.ui.renderHeader = function () {
  var s = SL.ui.store.state;
  var el = document.getElementById('app-header');
  var links = [
    ['#/catalog', 'Catalogue'],
    ['#/cart', 'Panier <span class="cart-badge">' + s.cartCount + '</span>'],
    ['#/orders', 'Mes commandes'],
    ['#/notifications', 'Boîte mail']
  ];
  if (s.user && SL.services.auth.isAdmin(s.user)) links.push(['#/admin', 'Back-office']);

  var nav = links.map(function (l) {
    var active = s.route && l[0].indexOf(s.route) === 2 ? ' class="active"' : '';
    return '<a href="' + l[0] + '"' + active + '>' + l[1] + '</a>';
  }).join('');

  var userZone = s.user
    ? '<span>👤 ' + SL.helpers.escapeHtml(s.user.name) + '</span><button class="btn link" id="logout-btn">Déconnexion</button>'
    : '<a href="#/login">Connexion</a>';

  el.innerHTML =
    '<a class="brand" href="#/catalog">🛒 ShopLegacy<small>v' + SL.version + '</small></a>' +
    '<nav>' + nav + '</nav>' +
    '<div class="user-zone"><a href="architecture.html" title="Vue architecture">🧭 Architecture</a>' + userZone + '</div>';

  var logout = document.getElementById('logout-btn');
  if (logout) {
    logout.onclick = function () {
      SL.api.post('/api/auth/logout').catch(function () {});
      SL.ui.store.set({ token: null, user: null });
      SL.app.refreshCartCount();
      location.hash = '#/catalog';
    };
  }
};
