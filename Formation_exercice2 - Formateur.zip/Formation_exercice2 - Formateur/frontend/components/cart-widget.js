/*
 * Lignes du panier + bloc de totaux.
 */
SL.ui.cartLines = function (cart) {
  if (!cart.items.length) return '<div class="empty">Votre panier est vide.</div>';
  var rows = cart.items.map(function (i) {
    return (
      '<tr>' +
      '<td>' + i.image + ' ' + SL.helpers.escapeHtml(i.name) + '</td>' +
      '<td>' + SL.helpers.formatPrice(i.price) + ' HT</td>' +
      '<td>' + i.qty + '</td>' +
      '<td>' + SL.helpers.formatPrice(i.price * i.qty) + ' HT</td>' +
      '<td><button class="btn small danger remove-item" data-id="' + i.productId + '">Retirer</button></td>' +
      '</tr>'
    );
  }).join('');
  return '<table><thead><tr><th>Produit</th><th>Prix</th><th>Qté</th><th>Total</th><th></th></tr></thead><tbody>' + rows + '</tbody></table>';
};

SL.ui.cartTotals = function (cart, shipping) {
  var html = '<div class="totals">' +
    '<div><span>Sous-total HT</span><span>' + SL.helpers.formatPrice(cart.subtotalHT) + '</span></div>' +
    '<div><span>TVA</span><span>' + SL.helpers.formatPrice(cart.tva) + '</span></div>';
  if (cart.promoCode) {
    html += '<div class="success"><span>Promo ' + cart.promoCode + '</span><span>-' + SL.helpers.formatPrice(cart.totalBeforePromo - cart.totalTTC) + '</span></div>';
  }
  if (shipping !== undefined) {
    html += '<div><span>Livraison</span><span>' + (shipping === 0 ? 'Offerte' : SL.helpers.formatPrice(shipping)) + '</span></div>';
  }
  html += '<div class="grand"><span>Total TTC</span><span>' + SL.helpers.formatPrice(cart.totalTTC + (shipping || 0)) + '</span></div></div>';
  return html;
};
