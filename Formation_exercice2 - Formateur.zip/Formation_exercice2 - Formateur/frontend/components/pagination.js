SL.ui.pagination = function (page, totalPages) {
  if (totalPages <= 1) return '';
  var html = '<div class="pagination">';
  for (var i = 1; i <= totalPages; i++) {
    html += '<button class="btn small page-btn' + (i === page ? ' current' : '') + '" data-page="' + i + '">' + i + '</button>';
  }
  return html + '</div>';
};
