SL.ui.loader = function (text) {
  return '<div class="loader">⏳ ' + (text || 'Chargement...') + '</div>';
};

SL.ui.statusBadge = function (status) {
  return '<span class="badge ' + status + '">' + status + '</span>';
};
