SL.ui.productCard = function (p) {
  var outOfStock = p.stock <= 0;
  return (
    '<div class="card product-card">' +
    '<div class="emoji">' + p.image + '</div>' +
    '<div class="name">' + SL.helpers.escapeHtml(p.name) + '</div>' +
    '<div class="meta"><span class="muted">' + (SL.shared.constants.CATEGORY_LABELS[p.category] || p.category) + '</span>' +
    '<span class="' + (p.stock <= 3 ? 'danger' : 'muted') + '">Stock : ' + p.stock + '</span></div>' +
    '<div class="price">' + SL.helpers.formatPrice(p.priceTTC) + ' <small class="muted">TTC</small></div>' +
    '<button class="btn add-to-cart" data-id="' + p.id + '"' + (outOfStock ? ' disabled' : '') + '>' +
    (outOfStock ? 'Rupture' : 'Ajouter au panier') + '</button>' +
    '</div>'
  );
};
