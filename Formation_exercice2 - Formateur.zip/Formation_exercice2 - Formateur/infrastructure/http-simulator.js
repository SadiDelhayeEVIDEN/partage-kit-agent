/*
 * Simulateur HTTP : simule un appel réseau (latence) vers l'API Gateway.
 * Chaque appel est journalisé dans la table "http_log" (pour architecture.html).
 * Header "x-caller" = service appelant (par défaut : frontend).
 */
SL.infra.http = {
  request: function (method, url, body, headers) {
    headers = headers || {};
    var cfg = SL.config.gateway;
    var latency = cfg.latencyMin + Math.random() * (cfg.latencyMax - cfg.latencyMin);
    var started = Date.now();
    var req = {
      method: method.toUpperCase(),
      url: url,
      body: body ? JSON.parse(JSON.stringify(body)) : null,
      headers: headers
    };

    return new Promise(function (resolve) {
      setTimeout(function () {
        Promise.resolve(SL.gateway.handle(req)).then(function (res) {
          SL.infra.http._log({
            at: started,
            from: headers['x-caller'] || 'frontend',
            to: res.service || '?',
            method: req.method,
            url: url,
            status: res.status,
            ms: Date.now() - started
          });
          resolve(res);
        });
      }, latency);
    });
  },

  _log: function (entry) {
    var log = SL.infra.storage.get('http_log');
    log.push(entry);
    if (log.length > 200) log = log.slice(-200);
    SL.infra.storage.save('http_log', log);
  }
};
