/*
 * Couche de persistance : chaque "table" est une clé localStorage.
 * Fallback mémoire si localStorage n'est pas disponible.
 */
(function () {
  var memory = {};
  var hasLocalStorage = (function () {
    try {
      localStorage.setItem('__sl_test', '1');
      localStorage.removeItem('__sl_test');
      return true;
    } catch (e) {
      return false;
    }
  })();

  function key(name) {
    return SL.config.storagePrefix + name;
  }

  function readRaw(name) {
    return hasLocalStorage ? localStorage.getItem(key(name)) : memory[key(name)];
  }

  function writeRaw(name, raw) {
    if (hasLocalStorage) localStorage.setItem(key(name), raw);
    else memory[key(name)] = raw;
  }

  SL.infra.storage = {
    get: function (table) {
      var raw = readRaw(table);
      if (!raw) return [];
      try {
        return JSON.parse(raw);
      } catch (e) {
        return [];
      }
    },

    save: function (table, rows) {
      writeRaw(table, JSON.stringify(rows));
    },

    getValue: function (name, defaultValue) {
      var raw = readRaw('kv_' + name);
      if (raw === null || raw === undefined) return defaultValue;
      try { return JSON.parse(raw); } catch (e) { return defaultValue; }
    },

    setValue: function (name, value) {
      writeRaw('kv_' + name, JSON.stringify(value));
    },

    removeValue: function (name) {
      if (hasLocalStorage) localStorage.removeItem(key('kv_' + name));
      else delete memory[key('kv_' + name)];
    },

    nextId: function (table) {
      var rows = this.get(table);
      var max = 0;
      for (var i = 0; i < rows.length; i++) {
        if (rows[i].id > max) max = rows[i].id;
      }
      return max + 1;
    },

    clear: function () {
      var prefix = SL.config.storagePrefix;
      if (hasLocalStorage) {
        var toDelete = [];
        for (var i = 0; i < localStorage.length; i++) {
          var k = localStorage.key(i);
          if (k && k.indexOf(prefix) === 0) toDelete.push(k);
        }
        toDelete.forEach(function (k) { localStorage.removeItem(k); });
      } else {
        for (var m in memory) if (m.indexOf(prefix) === 0) delete memory[m];
      }
    }
  };
})();
