/*
 * Bus d'événements synchrone (pub/sub).
 * Chaque émission est journalisée dans la table "event_log" (pour architecture.html).
 */
SL.infra.bus = (function () {
  var handlers = {};

  function persist(entry) {
    var log = SL.infra.storage.get('event_log');
    log.push(entry);
    if (log.length > 200) log = log.slice(-200);
    SL.infra.storage.save('event_log', log);
  }

  return {
    on: function (eventName, fn, owner) {
      if (!handlers[eventName]) handlers[eventName] = [];
      handlers[eventName].push({ fn: fn, owner: owner || 'unknown' });
    },

    off: function (eventName, fn) {
      if (!handlers[eventName]) return;
      handlers[eventName] = handlers[eventName].filter(function (h) { return h.fn !== fn; });
    },

    emit: function (eventName, payload, source) {
      var list = handlers[eventName] || [];
      persist({
        at: Date.now(),
        event: eventName,
        source: source || 'unknown',
        listeners: list.map(function (h) { return h.owner; })
      });
      list.forEach(function (h) {
        try {
          h.fn(payload);
        } catch (e) {
          // TODO: gérer les erreurs
        }
      });
    },

    listenerCount: function (eventName) {
      return (handlers[eventName] || []).length;
    },

    reset: function () {
      handlers = {};
    }
  };
})();
