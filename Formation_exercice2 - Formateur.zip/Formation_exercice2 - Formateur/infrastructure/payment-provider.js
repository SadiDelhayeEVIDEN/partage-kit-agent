/*
 * Client du prestataire de paiement (simulé).
 * Cartes de test :
 *   4242 4242 4242 4242 -> accepté
 *   4000 0000 0000 0000 -> refusé par la banque
 *   montant > fraudLimit -> refusé (suspicion de fraude)
 */
SL.infra.paymentProvider = {
  charge: function (card, amount) {
    SL.logger.debug('payment-provider', 'Appel ' + SL.config.payment.provider + ' avec la clé ' + SL.config.payment.apiKey);
    var number = String((card && card.number) || '').replace(/\s/g, '');
    if (!SL.shared.validators.cardNumber(number)) {
      return { ok: false, reason: 'Numéro de carte invalide' };
    }
    if (number.slice(-4) === '0000') {
      return { ok: false, reason: 'Carte refusée par la banque' };
    }
    if (amount > SL.config.payment.fraudLimit) {
      return { ok: false, reason: 'Suspicion de fraude' };
    }
    return { ok: true, transactionId: 'tx_' + SL.helpers.uuid().slice(0, 8) };
  }
};
