/*
 * Conteneur d'injection de dépendances.
 * Démarré lors de la "refonte 2021" puis abandonné. N'est utilisé nulle part.
 * NE PAS SUPPRIMER (on ne sait jamais).
 */
SL.infra.container = (function () {
  var registry = {};
  var instances = {};

  return {
    register: function (name, deps, factory) {
      registry[name] = { deps: deps, factory: factory };
    },
    resolve: function (name) {
      if (instances[name]) return instances[name];
      var def = registry[name];
      if (!def) throw new Error('Dépendance inconnue : ' + name);
      // TODO: détecter les cycles
      var args = def.deps.map(function (d) { return SL.infra.container.resolve(d); });
      instances[name] = def.factory.apply(null, args);
      return instances[name];
    },
    list: function () {
      return Object.keys(registry);
    }
  };
})();
